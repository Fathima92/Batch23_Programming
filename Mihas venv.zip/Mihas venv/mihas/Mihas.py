import tkinter as tk
from tkinter import simpledialog,messagebox
from decimal import Decimal
import hashlib
import mysql.connector

def connect_db():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cityelectronics"
    )
    return conn


current_customer = None
customers = []
orders = []

user_type = "admin"

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(stored_password, provided_password):
    return stored_password == hash_password(provided_password)

def get_user_from_db(username):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT username, password FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    conn.close()
    return user


def clear_window():
    for widget in root.winfo_children():
        widget.destroy()

def show_login_screen():
    clear_window()
    global user_type_label, login_button, switch_button, theme_button, entry_username, entry_password

    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.grid(row=0, column=0, columnspan=4, pady=10, sticky="n")

    user_type_label = tk.Label(root, text="Admin Login" if user_type == "admin" else "Customer Login", font=('Verdana', 20), bg=bg_color, fg=fg_color)
    user_type_label.grid(row=1, column=0, columnspan=4, pady=10, sticky="n")

    tk.Label(root, text="Username", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=2, column=1, padx=10, pady=2, sticky='w')
    entry_username = tk.Entry(root, font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
    entry_username.grid(row=3, column=1, columnspan=2, padx=10, pady=10, sticky='we')

    tk.Label(root, text="Password", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=4, column=1, padx=10, pady=2, sticky='w')
    entry_password = tk.Entry(root, show="*", font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
    entry_password.grid(row=5, column=1, columnspan=2, padx=10, pady=10, sticky='we')

    login_button = tk.Button(root, text="Login", command=lambda: validate_login(user_type), font=('Verdana', 16), bg=btn_color, fg=fg_color)
    login_button.grid(row=6, column=1, padx=10, pady=10, sticky="e")

    switch_button = tk.Button(root, text="Customer" if user_type == "admin" else "Admin", command=switch_user_type, font=('Verdana', 16), bg=btn_color, fg=fg_color)
    switch_button.grid(row=6, column=2, padx=10, pady=10, sticky="w")

def validate_login(user_type):
    global current_customer
    username = entry_username.get()
    password = entry_password.get()

    if user_type == "admin":
        user = get_user_from_db(username)
        if user and verify_password(user[1], password):
            print("Admin login successful!")
            current_customer = username
            open_customer_dashboard()
        else:
            print("Invalid credentials")
            messagebox.showerror("Login Failed", "Invalid username or password")
    elif user_type == "customer":
        user = get_user_from_db(username)
        if user and verify_password(user[1], password):
            print("Customer login successful!")
            current_customer = username
            open_customer_dashboard()
        else:
            print("Invalid credentials")
            messagebox.showerror("Login Failed", "Invalid username or password")


def switch_user_type():
    global user_type
    user_type = "customer" if user_type == "admin" else "admin"
    show_login_screen()

def on_enter(event):
    event.widget.config(bg="#6c757d")

def on_leave(event):
    event.widget.config(bg=btn_color)

def add_product():
    product_name = simpledialog.askstring("Input", "Enter the product name:")
    product_price = simpledialog.askstring("Input", "Enter the product price:")
    if product_name and product_price:
        try:
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO products (product_name, price) VALUES (%s, %s)", (product_name, product_price))
            conn.commit()
            conn.close()
            refresh_product_list()
            messagebox.showinfo("Success", "Product added successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add product: {e}")
    else:
        messagebox.showwarning("Input Error", "Please fill all fields")


def modify_product():
    selected_product_index = product_list.curselection()
    if not selected_product_index:
        messagebox.showwarning("No Selection", "Please select a product to modify.")
        return

    selected_product = product_list.get(selected_product_index)
    product_name = selected_product.split(' - ')[0]
    product_price = selected_product.split(' - ')[1]

    new_name = simpledialog.askstring("Input", "Enter the new product name:", initialvalue=product_name)
    new_price = simpledialog.askstring("Input", "Enter the new product price:", initialvalue=product_price)

    if new_name and new_price:
        try:
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("UPDATE products SET product_name = %s, price = %s WHERE product_name = %s AND price = %s", (new_name, new_price, product_name, product_price))
            conn.commit()
            conn.close()
            refresh_product_list()
            messagebox.showinfo("Success", "Product modified successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to modify product: {e}")
    else:
        messagebox.showwarning("Input Error", "Please fill all fields")

def remove_product():
    selected_product_index = product_list.curselection()
    if not selected_product_index:
        messagebox.showwarning("No Selection", "Please select a product to remove.")
        return

    selected_product = product_list.get(selected_product_index)
    product_name = selected_product.split(' - ')[0]
    product_price = selected_product.split(' - ')[1]

    confirm = messagebox.askyesno("Confirm", f"Are you sure you want to remove the product '{product_name}'?")
    if confirm:
        try:
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM products WHERE product_name = %s AND price = %s", (product_name, product_price))
            conn.commit()
            conn.close()
            refresh_product_list()
            messagebox.showinfo("Success", "Product removed successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to remove product: {e}")



def refresh_product_list():
    global product_list_prices  # Add a global variable to store product prices
    product_list_prices = {}

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products")
    rows = cursor.fetchall()
    conn.close()

    product_list.delete(0, tk.END)
    for row in rows:
        product_name = row[1]
        product_price = row[2]
        product_display = f"{product_name} - {product_price}"
        product_list.insert(tk.END, product_display)
        product_list_prices[product_display] = product_price  # Store the price in a dictionary



def refresh_order_list():
    if 'order_list' in globals():
        order_list.delete(0, tk.END)
        for order in orders:
            customer = order.get('customer', 'Unknown')
            details = order.get('details', [])
            total = order.get('total', Decimal(0))

            if details:
                details_str = ', '.join([f"{item['product']} (x{item['quantity']})" for item in details])
                order_display = f"{customer}: {details_str} - Total: ${total:.2f}"
            else:
                order_display = f"{customer}: Order details not available - Total: ${total:.2f}"

            order_list.insert(tk.END, order_display)



def cancel_order():
    selected_order = order_list.curselection()
    if selected_order:
        order_index = selected_order[0]
        del orders[order_index]
        refresh_order_list()
    else:
        tk.messagebox.showerror("Error", "No order selected.")

def open_product_management():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)

    back_button = tk.Button(root, text="←", command=open_admin_dashboard, font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)

    tk.Label(root, text="Product Management", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    global product_list
    product_list = tk.Listbox(root, font=('Verdana', 12), bg=entry_bg_color, fg=fg_color)
    product_list.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    tk.Button(root, text="Add Product", command=add_product, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Modify Product", command=modify_product, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Remove Product", command=remove_product, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)

    refresh_product_list()


def refresh_customer_list():
    pass

def open_orders_dashboard():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)

    back_button = tk.Button(root, text="←",
                            command=open_admin_dashboard if user_type == "admin" else open_customer_dashboard,
                            font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)

    tk.Label(root, text="Orders Dashboard", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    order_frame = tk.Frame(root, bg=bg_color)
    order_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    global order_list
    order_list = tk.Listbox(order_frame, font=('Verdana', 12), bg=entry_bg_color, fg=fg_color)
    order_list.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    refresh_order_list()



def open_customer_dashboard():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)

    back_button = tk.Button(root, text="←", command=switch_user_type, font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)

    tk.Label(root, text="Customer Dashboard", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    if user_type == "admin":
        back_button = tk.Button(root, text="←", command=open_admin_dashboard, font=('Verdana', 12), bg=btn_color, fg=fg_color)
        back_button.place(x=10, y=10)

    global product_list
    product_list = tk.Listbox(root, font=('Verdana', 12), bg=entry_bg_color, fg=fg_color, selectmode=tk.MULTIPLE)
    product_list.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    refresh_product_list()
    tk.Button(root, text="Order Products", command=open_order_products, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)


def open_admin_dashboard():
    clear_window()
    name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
    name_label.pack(pady=10)
    back_button = tk.Button(root, text="←", command=switch_user_type, font=('Verdana', 12), bg=btn_color, fg=fg_color)
    back_button.place(x=10, y=10)
    tk.Label(root, text="Admin Dashboard", font=('Verdana', 20), bg=bg_color, fg=fg_color).pack(pady=10)

    tk.Button(root, text="Product Management", command=open_product_management, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Customer Dashboard", command=open_customer_dashboard, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)
    tk.Button(root, text="Orders Dashboard", command=open_orders_dashboard, font=('Verdana', 12), bg=btn_color, fg=fg_color).pack(pady=5)


def open_order_products():
    selected_indices = product_list.curselection()
    selected_products = [product_list.get(i) for i in selected_indices]

    if not selected_products:
        messagebox.showwarning("No Selection", "Please select at least one product to order.")
        return

    order_details = []
    total_amount = Decimal(0)

    for product in selected_products:
        quantity_var = tk.simpledialog.askstring("Quantity", f"Enter quantity for {product}:", initialvalue='1')
        if not quantity_var.isdigit() or int(quantity_var) <= 0:
            messagebox.showwarning("Invalid Input", "Please enter a valid quantity.")
            return

        quantity = int(quantity_var)
        product_price = Decimal(product_list_prices[product])
        total_amount += quantity * product_price
        product_name = product.split(' - ')[0]
        order_details.append({'product': product_name, 'quantity': quantity, 'price': product_price})

    total_amount = round(total_amount, 2)

    orders.append({'customer': current_customer, 'details': order_details, 'total': total_amount})

    messagebox.showinfo("Order Placed", f"Order placed successfully! Total amount: ${total_amount:.2f}")

    print(f"Order submitted: {order_details}")
    print(f"Total amount: {total_amount}")

    refresh_order_list()


def calculate_total_amount():
    total = 0
    for product, quantity_var in product_entries:
        quantity = int(quantity_var.get())
        if quantity > 0:
            total += quantity * product_prices[product]
    return total

def update_total_price():
    total_price = calculate_total_amount()
    total_price_label.config(text=f"Total: ${total_price}")

def submit_order():
    global orders
    order_details = []
    for product, quantity_var in product_entries:
        quantity = int(quantity_var.get())
        if quantity > 0:
            order_details.append({'product': product, 'quantity': quantity})
    total_amount = calculate_total_amount()
    orders.append({'customer': current_customer, 'details': order_details, 'total': total_amount})
    print(f"Order submitted: {order_details}")
    print(f"Total amount: {total_amount}")

root = tk.Tk()
root.title("City Electronics")
root.geometry('800x600')
bg_color = "black"
fg_color = "white"
btn_color = "dim gray"
entry_bg_color = "black"
entry_fg_color = "black"
root.configure(bg=bg_color)
root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(11, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
root.grid_columnconfigure(3, weight=1)

show_login_screen()

name_label = tk.Label(root, text="City Electronics", font=('Georgia', 24, 'bold'), bg=bg_color, fg=fg_color)
name_label.grid(row=0, column=0, columnspan=4, pady=10, sticky="n")

user_type_label = tk.Label(root, text="Admin Login", font=('Verdana', 20), bg=bg_color, fg=fg_color)
user_type_label.grid(row=1, column=0, columnspan=4, pady=10, sticky="n")

tk.Label(root, text="Username", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=2, column=1, padx=10, pady=2, sticky='w')
entry_username = tk.Entry(root, font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
entry_username.grid(row=3, column=1, columnspan=2, padx=10, pady=10, sticky='we')

tk.Label(root, text="Password", font=('Verdana', 12), bg=bg_color, fg=fg_color).grid(row=4, column=1, padx=10, pady=2, sticky='w')
entry_password = tk.Entry(root, show="*", font=('Verdana', 16), width=10, bg=entry_bg_color, fg=fg_color)
entry_password.grid(row=5, column=1, columnspan=2, padx=10, pady=10, sticky='we')

login_button = tk.Button(root, text="Login", command=lambda: validate_login("admin"), font=('Verdana', 16), bg=btn_color, fg=fg_color)
login_button.grid(row=6, column=1, padx=10, pady=10, sticky="e")

switch_button = tk.Button(root, text="Customer", command=switch_user_type, font=('Verdana', 16), bg=btn_color, fg=fg_color)
switch_button.grid(row=6, column=2, padx=10, pady=10, sticky="w")

root.mainloop()

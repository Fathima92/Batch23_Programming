import tkinter as tk
from tkinter import messagebox
import mysql.connector

def connect_to_db():
    return mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="",
        database="customer dp."
    )

def admin_login():
    def verify_admin():
        username = admin_username_entry.get()
        password = admin_password_entry.get()
        if username == "Ashrifadh" and password == "Ashrif223344":
            messagebox.showinfo("Login Successful", "Welcome, Admin!")
            admin_options()
        else:
            messagebox.showerror("Login Failed", "Invalid admin credentials")

    admin_window = tk.Toplevel()
    admin_window.title("Admin Login")
    admin_window.geometry("350x250")
    admin_window.config(bg="#F0F8FF")

    tk.Label(admin_window, text="Username", font=("Helvetica", 12, "bold"), fg="#333", bg="#F0F8FF").pack(pady=10)
    admin_username_entry = tk.Entry(admin_window, font=("Helvetica", 12), bg="#FFF", bd=2, relief="solid")
    admin_username_entry.pack(pady=10, padx=20)

    tk.Label(admin_window, text="Password", font=("Helvetica", 12, "bold"), fg="#333", bg="#F0F8FF").pack(pady=10)
    admin_password_entry = tk.Entry(admin_window, font=("Helvetica", 12), bg="#FFF", bd=2, relief="solid", show="*")
    admin_password_entry.pack(pady=10, padx=20)

    tk.Button(admin_window, text="Login", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=verify_admin).pack(pady=20)

def customer_login():
    def verify_customer():
        db = connect_to_db()
        cursor = db.cursor()
        username = customer_username_entry.get()
        password = customer_password_entry.get()
        query = "SELECT * FROM users WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()
        db.close()

        if result:
            messagebox.showinfo("Login Successful", "Welcome, Customer!")
            customer_options()
        else:
            messagebox.showerror("Login Failed", "Invalid customer credentials")

    customer_window = tk.Toplevel()
    customer_window.title("Customer Login")
    customer_window.geometry("350x250")
    customer_window.config(bg="#F0F8FF")

    tk.Label(customer_window, text="Username", font=("Helvetica", 12, "bold"), fg="#333", bg="#F0F8FF").pack(pady=10)
    customer_username_entry = tk.Entry(customer_window, font=("Helvetica", 12), bg="#FFF", bd=2, relief="solid")
    customer_username_entry.pack(pady=10, padx=20)

    tk.Label(customer_window, text="Password", font=("Helvetica", 12, "bold"), fg="#333", bg="#F0F8FF").pack(pady=10)
    customer_password_entry = tk.Entry(customer_window, font=("Helvetica", 12), bg="#FFF", bd=2, relief="solid", show="*")
    customer_password_entry.pack(pady=10, padx=20)

    tk.Button(customer_window, text="Login", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=verify_customer).pack(pady=20)

def admin_options():
    def view_products():
        db = connect_to_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()
        db.close()

        products_window = tk.Toplevel()
        products_window.title("Products")
        products_window.geometry("400x300")
        products_window.config(bg="#F0F8FF")

        for product in products:
            tk.Label(products_window, text=f"ID: {product[0]}, Name: {product[1]}, Price: {product[2]}", font=("Helvetica", 12), fg="#333", bg="#F0F8FF").pack(pady=5)

        tk.Button(products_window, text="Exit", font=("Helvetica", 12), fg="#FFF", bg="#FF4500", bd=0, relief="flat", command=products_window.destroy).pack(pady=10)

    def modify_products():
        def update_product():
            product_id = product_id_entry.get()
            new_price = new_price_entry.get()

            db = connect_to_db()
            cursor = db.cursor()
            cursor.execute("UPDATE products SET price = %s WHERE id = %s", (new_price, product_id))
            db.commit()
            db.close()

            messagebox.showinfo("Success", "Product price updated")
            modify_window.destroy()

        def delete_product():
            product_id = product_id_entry.get()

            db = connect_to_db()
            cursor = db.cursor()
            cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
            db.commit()
            db.close()

            messagebox.showinfo("Success", "Product deleted")
            modify_window.destroy()

        modify_window = tk.Toplevel()
        modify_window.title("Modify Products")
        modify_window.geometry("350x250")
        modify_window.config(bg="#F0F8FF")

        tk.Label(modify_window, text="Product ID", font=("Helvetica", 12, "bold"), fg="#333", bg="#F0F8FF").pack(pady=10)
        product_id_entry = tk.Entry(modify_window, font=("Helvetica", 12), bg="#FFF", bd=2, relief="solid")
        product_id_entry.pack(pady=10, padx=20)

        tk.Label(modify_window, text="New Price", font=("Helvetica", 12, "bold"), fg="#333", bg="#F0F8FF").pack(pady=10)
        new_price_entry = tk.Entry(modify_window, font=("Helvetica", 12), bg="#FFF", bd=2, relief="solid")
        new_price_entry.pack(pady=10, padx=20)

        tk.Button(modify_window, text="Update Price", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=update_product).pack(pady=10)
        tk.Button(modify_window, text="Delete Product", font=("Helvetica", 12), fg="#FFF", bg="#FF4500", bd=0, relief="flat", command=delete_product).pack(pady=10)

    admin_window = tk.Toplevel()
    admin_window.title("Admin Options")
    admin_window.geometry("350x250")
    admin_window.config(bg="#F0F8FF")

    tk.Button(admin_window, text="View Products", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=view_products).pack(pady=15)
    tk.Button(admin_window, text="Modify Products", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=modify_products).pack(pady=15)
    tk.Button(admin_window, text="Exit", font=("Helvetica", 12), fg="#FFF", bg="#FF4500", bd=0, relief="flat", command=admin_window.destroy).pack(pady=15)

def customer_options():
    def view_products():
        db = connect_to_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()
        db.close()

        products_window = tk.Toplevel()
        products_window.title("Products")
        products_window.geometry("400x300")
        products_window.config(bg="#F0F8FF")

        for product in products:
            tk.Label(products_window, text=f"ID: {product[0]}, Name: {product[1]}, Price: {product[2]}", font=("Helvetica", 12), fg="#333", bg="#F0F8FF").pack(pady=5)

        tk.Button(products_window, text="Exit", font=("Helvetica", 12), fg="#FFF", bg="#FF4500", bd=0, relief="flat", command=products_window.destroy).pack(pady=10)

    customer_window = tk.Toplevel()
    customer_window.title("Customer Options")
    customer_window.geometry("350x250")
    customer_window.config(bg="#F0F8FF")

    tk.Button(customer_window, text="View Products", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=view_products).pack(pady=20)
    tk.Button(customer_window, text="Exit", font=("Helvetica", 12), fg="#FFF", bg="#FF4500", bd=0, relief="flat", command=customer_window.destroy).pack(pady=20)

root = tk.Tk()
root.title("City Electronics")
root.geometry("350x250")
root.config(bg="#F0F8FF")

signin_label = tk.Label(root, text="City Electronics", font=("Helvetica", 18, "bold"), fg="#333", bg="#F0F8FF")
signin_label.pack(pady=30)

admin_login_button = tk.Button(root, text="Admin Login", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=admin_login)
admin_login_button.pack(pady=10)

customer_login_button = tk.Button(root, text="Customer Login", font=("Helvetica", 12), fg="#FFF", bg="#1E90FF", bd=0, relief="flat", command=customer_login)
customer_login_button.pack(pady=10)

tk.Button(root, text="Exit", font=("Helvetica", 12), fg="#FFF", bg="#FF4500", bd=0, relief="flat", command=root.quit).pack(pady=20)

root.mainloop()

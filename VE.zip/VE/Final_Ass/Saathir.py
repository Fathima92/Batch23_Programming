import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import mysql.connector


# MySQL Database Configuration
def db_connect():
    """Establish a connection to the database."""
    try:
        conn = mysql.connector.connect(
            host="localhost",  # Your database host
            user="root",  # Your database username
            password="",  # Your database password
            database="cityelectronics"  # The name of your database
        )
        return conn
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")
        exit()


class CityElectronicsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("City Electronics")
        self.root.geometry("800x600")
        self.root.resizable(False, False)

        # Initialize cart for customer
        self.cart = []

        # Establish the database connection and initialize cursor
        self.db_connection = db_connect()  # Make sure this establishes the connection
        if self.db_connection:
            self.cursor = self.db_connection.cursor()  # Initialize cursor here
            print("Database connected successfully!")
        else:
            messagebox.showerror("Database Error", "Unable to connect to the database.")
            exit()

        # Create login page
        self.create_login_page()

    def clear_frame(self):
        """Clears the current frame for navigation."""
        for widget in self.root.winfo_children():
            widget.destroy()

        # Connect to MySQL database
        conn = db_connect()  # Directly call the db_connect function
        if conn:
            self.db_connection = conn
            self.cursor = self.db_connection.cursor()
            print("Database connected successfully!")
        else:
            messagebox.showerror("Database Error", "Unable to connect to the database.")
            exit()

        self.create_login_page()

    def create_login_page(self):
        """Creates the login page."""
        self.clear_frame()

        # Title
        title_label = tk.Label(self.root, text="Welcome to City Electronics",
                               font=("Mongolian Baiti", 28, "bold"), fg="Yellow", bg="#c31432")
        title_label.pack(pady=80, fill=tk.X)

        # Buttons for Admin and Customer Login
        admin_btn = tk.Button(self.root, text="Admin Login", command=self.admin_login_page,
                              bg="blue", fg="white", font=("Arial", 14), width=15, bd=2)
        admin_btn.pack(pady=20)

        customer_btn = tk.Button(self.root, text="Customer Login", command=self.customer_login_page,
                                 bg="Blue", fg="white", font=("Arial", 14), width=15, bd=2)
        customer_btn.pack(pady=20)

        exit_btn = tk.Button(self.root, text="Exit", command=self.root.quit,
                             bg="red", fg="white", font=("Arial", 14), width=10, bd=2)
        exit_btn.pack(pady=20)

    def admin_login_page(self):
        """Creates the admin login page."""
        self.clear_frame()

        # Title
        title_label = tk.Label(self.root, text="Admin Login",
                               font=("Helvetica", 28, "bold"), fg="white", bg="#240b36")
        title_label.pack(pady=50, fill=tk.X)

        # Username and Password Entry
        username_label = tk.Label(self.root, text="Username:", font=("Arial", 14))
        username_label.pack(pady=5)
        self.admin_user = tk.Entry(self.root, font=("Arial", 14), width=25)
        self.admin_user.pack(pady=5)

        password_label = tk.Label(self.root, text="Password:", font=("Arial", 14))
        password_label.pack(pady=5)
        self.admin_pass = tk.Entry(self.root, show="*", font=("Arial", 14), width=25)
        self.admin_pass.pack(pady=5)

        # Login Button
        login_btn = tk.Button(self.root, text="Login", command=self.validate_admin,
                              bg="blue", fg="white", font=("Arial", 14), width=15, bd=2)
        login_btn.pack(pady=20)

        # Back Button
        back_btn = tk.Button(self.root, text="Back", command=self.create_login_page,
                             bg="red", fg="white", font=("Arial", 14), width=15, bd=2)
        back_btn.pack(pady=10)

    def customer_login_page(self):
        """Creates the customer login page."""
        self.clear_frame()

        # Title
        title_label = tk.Label(self.root, text="Customer Login",
                               font=("Helvetica", 28, "bold"), fg="white", bg="#c31432")
        title_label.pack(pady=50, fill=tk.X)

        # Username and Password Entry
        username_label = tk.Label(self.root, text="Username:", font=("Arial", 14))
        username_label.pack(pady=5)
        self.customer_user = tk.Entry(self.root, font=("Arial", 14), width=25)
        self.customer_user.pack(pady=5)

        password_label = tk.Label(self.root, text="Password:", font=("Arial", 14))
        password_label.pack(pady=5)
        self.customer_pass = tk.Entry(self.root, show="*", font=("Arial", 14), width=25)
        self.customer_pass.pack(pady=5)

        # Login Button
        login_btn = tk.Button(self.root, text="Login", command=self.validate_customer,
                              bg="green", fg="white", font=("Arial", 14), width=15, bd=2)
        login_btn.pack(pady=20)

        # Back Button
        back_btn = tk.Button(self.root, text="Back", command=self.create_login_page,
                             bg="red", fg="white", font=("Arial", 14), width=15, bd=2)
        back_btn.pack(pady=10)

    def validate_admin(self):
        """Validates admin credentials."""
        username = self.admin_user.get()
        password = self.admin_pass.get()

        query = "SELECT * FROM User WHERE UserName = %s AND Password = %s AND Role = 'admin'"
        self.cursor.execute(query, (username, password))
        result = self.cursor.fetchone()

        if result:
            messagebox.showinfo("Login Success", "Welcome Admin!")
            self.admin_dashboard()
        else:
            messagebox.showerror("Login Failed", "Invalid Admin Credentials!")

    def validate_customer(self):
        """Validates customer credentials."""
        username = self.customer_user.get()
        password = self.customer_pass.get()

        query = "SELECT * FROM User WHERE UserName = %s AND Password = %s AND Role = 'customer'"
        self.cursor.execute(query, (username, password))
        result = self.cursor.fetchone()

        if result:
            messagebox.showinfo("Login Success", "Welcome Customer!")
            self.customer_dashboard()
        else:
            messagebox.showerror("Login Failed", "Invalid Customer Credentials!")

    def admin_dashboard(self):
        """Admin dashboard with content."""
        self.clear_frame()

        title_label = tk.Label(self.root, text="Admin Dashboard",
                               font=("Arial", 20), bg="blue", fg="white")
        title_label.pack(pady=20, fill=tk.X)

        # Add Product Button
        add_product_btn = tk.Button(self.root, text="Add Product", command=self.add_product,
                                    bg="green", fg="white", font=("Arial", 14), width=20, bd=2)
        add_product_btn.pack(pady=10)

        # Modify Product Button
        modify_product_btn = tk.Button(self.root, text="Modify Product", command=self.modify_product,
                                       bg="orange", fg="white", font=("Arial", 14), width=20, bd=2)
        modify_product_btn.pack(pady=10)

        # Remove Product Button
        remove_product_btn = tk.Button(self.root, text="Remove Product", command=self.remove_product,
                                       bg="red", fg="white", font=("Arial", 14), width=20, bd=2)
        remove_product_btn.pack(pady=10)

        # Logout Button
        logout_btn = tk.Button(self.root, text="Logout", command=self.create_login_page,
                               bg="red", fg="white", font=("Arial", 14), width=20, bd=2)
        logout_btn.pack(pady=20)

    def add_product(self):
        """Creates the Add Product page where the admin can add a new product to the database."""
        self.clear_frame()

        # Title
        title_label = tk.Label(self.root, text="Add New Product", font=("Arial", 20), bg="green", fg="white")
        title_label.pack(pady=20, fill=tk.X)

        # Product Name Entry
        name_label = tk.Label(self.root, text="Product Name:", font=("Arial", 14))
        name_label.pack(pady=5)
        self.product_name = tk.Entry(self.root, font=("Arial", 14), width=25)
        self.product_name.pack(pady=5)

        # Product Price Entry
        price_label = tk.Label(self.root, text="Product Price:", font=("Arial", 14))
        price_label.pack(pady=5)
        self.product_price = tk.Entry(self.root, font=("Arial", 14), width=25)
        self.product_price.pack(pady=5)

        # Add Product Button
        add_btn = tk.Button(self.root, text="Add Product", command=self.insert_product,
                            bg="blue", fg="white", font=("Arial", 14), width=15, bd=2)
        add_btn.pack(pady=20)

        # Back Button
        back_btn = tk.Button(self.root, text="Back", command=self.admin_dashboard,
                             bg="red", fg="white", font=("Arial", 14), width=15, bd=2)
        back_btn.pack(pady=10)

    def insert_product(self):
        """Inserts a new product into the database."""
        product_name = self.product_name.get()
        product_price = self.product_price.get()

        if not product_name or not product_price:
            messagebox.showerror("Input Error", "Please enter both product name and price.")
            return

        try:
            query = "INSERT INTO Product (ProductName, ProductPrice) VALUES (%s, %s)"
            self.cursor.execute(query, (product_name, product_price))
            self.db_connection.commit()
            messagebox.showinfo("Success", "Product added successfully!")
            self.admin_dashboard()  # Go back to admin dashboard after successful addition
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    def modify_product(self):
        """Creates the Modify Product page where the admin can modify an existing product."""
        self.clear_frame()

        # Title
        title_label = tk.Label(self.root, text="Modify Product", font=("Arial", 20), bg="orange", fg="white")
        title_label.pack(pady=20, fill=tk.X)

        # Product List Frame
        product_list_frame = tk.Frame(self.root)
        product_list_frame.pack(pady=10)

        # Create Treeview to display products
        product_table = ttk.Treeview(product_list_frame, columns=("Product ID", "Product Name", "Price"),
                                     show="headings")
        product_table.heading("Product ID", text="Product ID")
        product_table.heading("Product Name", text="Product Name")
        product_table.heading("Price", text="Price")
        product_table.column("Product ID", width=100)
        product_table.column("Product Name", width=200)
        product_table.column("Price", width=100)
        product_table.pack()

        # Fetch products from the database
        query = "SELECT ProductID, ProductName, ProductPrice FROM Product"
        self.cursor.execute(query)
        products = self.cursor.fetchall()

        # Insert products into the table
        for product in products:
            product_table.insert("", "end", values=(product[0], product[1], product[2]))

        # Modify Product Button
        modify_btn = tk.Button(self.root, text="Modify Selected Product",
                               command=lambda: self.select_product_for_modification(product_table),
                               bg="blue", fg="white", font=("Arial", 14), width=20, bd=2)
        modify_btn.pack(pady=20)

        # Back Button
        back_btn = tk.Button(self.root, text="Back", command=self.admin_dashboard,
                             bg="red", fg="white", font=("Arial", 14), width=15, bd=2)
        back_btn.pack(pady=10)

    def select_product_for_modification(self, product_table):
        """Select a product and allow the admin to modify its details."""
        selected_item = product_table.focus()  # Get selected row
        if selected_item:
            product = product_table.item(selected_item, "values")
            product_id = product[0]  # Get the product ID

            # Ask for new name and price
            new_name = simpledialog.askstring("Modify Product", "Enter new product name:", initialvalue=product[1])
            new_price = simpledialog.askfloat("Modify Product", "Enter new product price:",
                                              initialvalue=float(product[2]))

            if new_name and new_price:
                try:
                    query = "UPDATE Product SET ProductName = %s, ProductPrice = %s WHERE ProductID = %s"
                    self.cursor.execute(query, (new_name, new_price, product_id))
                    self.db_connection.commit()
                    messagebox.showinfo("Success", "Product updated successfully!")
                    self.admin_dashboard()  # Go back to admin dashboard after modification
                except mysql.connector.Error as err:
                    messagebox.showerror("Database Error", f"Error: {err}")
            else:
                messagebox.showerror("Input Error", "Please enter valid product details.")
        else:
            messagebox.showerror("Selection Error", "Please select a product to modify.")

    def remove_product(self):
        """Creates the Remove Product page where the admin can remove a product from the database."""
        self.clear_frame()

        # Title
        title_label = tk.Label(self.root, text="Remove Product", font=("Arial", 20), bg="red", fg="white")
        title_label.pack(pady=20, fill=tk.X)

        # Product List Frame
        product_list_frame = tk.Frame(self.root)
        product_list_frame.pack(pady=10)

        # Create Treeview to display products
        product_table = ttk.Treeview(product_list_frame, columns=("Product ID", "Product Name", "Price"),
                                     show="headings")
        product_table.heading("Product ID", text="Product ID")
        product_table.heading("Product Name", text="Product Name")
        product_table.heading("Price", text="Price")
        product_table.column("Product ID", width=100)
        product_table.column("Product Name", width=200)
        product_table.column("Price", width=100)
        product_table.pack()

        # Fetch products from the database
        query = "SELECT ProductID, ProductName, ProductPrice FROM Product"
        self.cursor.execute(query)
        products = self.cursor.fetchall()

        # Insert products into the table
        for product in products:
            product_table.insert("", "end", values=(product[0], product[1], product[2]))

        # Remove Product Button
        remove_btn = tk.Button(self.root, text="Remove Selected Product",
                               command=lambda: self.select_product_for_removal(product_table),
                               bg="blue", fg="white", font=("Arial", 14), width=20, bd=2)
        remove_btn.pack(pady=20)

        # Back Button
        back_btn = tk.Button(self.root, text="Back", command=self.admin_dashboard,
                             bg="red", fg="white", font=("Arial", 14), width=15, bd=2)
        back_btn.pack(pady=10)

    def select_product_for_removal(self, product_table):
        """Select a product and allow the admin to remove it."""
        selected_item = product_table.focus()  # Get selected row
        if selected_item:
            product = product_table.item(selected_item, "values")
            product_id = product[0]  # Get the product ID

            # Ask for confirmation before removal
            confirm = messagebox.askyesno("Confirm Removal", f"Are you sure you want to remove {product[1]}?")
            if confirm:
                try:
                    # Remove product from the database
                    query = "DELETE FROM Product WHERE ProductID = %s"
                    self.cursor.execute(query, (product_id,))
                    self.db_connection.commit()
                    messagebox.showinfo("Success", "Product removed successfully!")
                    self.admin_dashboard()  # Go back to admin dashboard after removal
                except mysql.connector.Error as err:
                    messagebox.showerror("Database Error", f"Error: {err}")
        else:
            messagebox.showerror("Selection Error", "Please select a product to remove.")

    def customer_dashboard(self):
        """Customer dashboard where products can be selected and total calculated."""
        self.clear_frame()

        # Title
        title_label = tk.Label(self.root, text="Customer Dashboard",
                               font=("Arial", 20), bg="green", fg="white")
        title_label.pack(pady=20, fill=tk.X)

        # Product List
        product_list_frame = tk.Frame(self.root)
        product_list_frame.pack(pady=10)

        product_table = ttk.Treeview(product_list_frame, columns=("Product Name", "Price"), show="headings")
        product_table.heading("Product Name", text="Product Name")
        product_table.heading("Price", text="Price")
        product_table.column("Product Name", width=300)
        product_table.column("Price", width=100)
        product_table.pack()

        # Add products to the table from the database
        conn = db_connect()
        cursor = conn.cursor()
        cursor.execute("SELECT ProductName, ProductPrice FROM Product")
        products = cursor.fetchall()
        conn.close()

        for product in products:
            product_table.insert("", "end", values=(product[0], product[1]))

        # Add to Cart Button
        add_to_cart_btn = tk.Button(self.root, text="Add to Cart", command=lambda: self.add_to_cart(product_table),
                                    bg="blue", fg="white", font=("Arial", 14), width=15, bd=2)
        add_to_cart_btn.pack(pady=20)

        # Cart and Total
        self.total_label = tk.Label(self.root, text="Total: $0", font=("Arial", 16), fg="black")
        self.total_label.pack(pady=10)

        # Checkout Button
        checkout_btn = tk.Button(self.root, text="Checkout", command=self.checkout,
                                 bg="green", fg="white", font=("Arial", 14), width=15, bd=2)
        checkout_btn.pack(pady=10)

        # Back Button
        back_btn = tk.Button(self.root, text="Back", command=self.create_login_page,
                             bg="red", fg="white", font=("Arial", 14), width=15, bd=2)
        back_btn.pack(pady=20)

    def clear_frame(self):
        """Clears the current frame for navigation."""
        for widget in self.root.winfo_children():
            widget.destroy()

    def add_to_cart(self, product_table):
        """Adds selected product to the cart."""
        selected_item = product_table.focus()
        if selected_item:
            product = product_table.item(selected_item, "values")
            self.cart.append(product)
            messagebox.showinfo("Added to Cart", f"{product[0]} added to the cart!")
            self.update_total()
        else:
            messagebox.showerror("Error", "Please select a product to add to the cart.")

    def update_total(self):
        """Updates the total price of the products in the cart."""
        total = sum(float(product[1]) for product in self.cart)
        self.total_label.config(text=f"Total: ${total:.2f}")

    def checkout(self):
        """Finalizes the cart and displays the total payment."""
        if not self.cart:
            messagebox.showwarning("Cart Empty", "Your cart is empty!")
        else:
            total = sum(float(product[1]) for product in self.cart)
            messagebox.showinfo("Checkout", f"Your total is ${total:.2f}. Thank you for shopping!")
            self.cart.clear()
            self.update_total()


# Main Application Execution
if __name__ == "__main__":
    root = tk.Tk()
    app = CityElectronicsApp(root)
    root.mainloop()

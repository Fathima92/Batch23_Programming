import tkinter as tk
from tkinter import messagebox
import mysql.connector

# Define global font styles
FONT_LABEL = ("Arial", 14, "bold")
FONT_ENTRY = ("Arial", 14)
FONT_BUTTON = ("Arial", 14, "bold")
BACKGROUND_COLOR = "#2f2f2f"  # Soft gray color
BUTTON_COLOR = "#4CAF50"  # Green for buttons
BUTTON_HOVER_COLOR = "#45a049"  # Darker green for hover effect
TEXT_COLOR = "white"

# Function to connect to the MySQL database
def connect_to_db():
    try:
        return mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="",  # Update with your MySQL root password
            database="customerjaasir"
        )
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")
        return None

# Function to add a new customer to the database
def add_customer(name, email):
    conn = connect_to_db()
    if conn is None:
        return
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO customers (name, email) VALUES (%s, %s)", (name, email))
        conn.commit()
        messagebox.showinfo("Success", "Customer added successfully")
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

# Admin login window
def admin_login():
    def verify_admin():
        username = admin_username_entry.get()
        password = admin_password_entry.get()

        if not username or not password:
            messagebox.showerror("Input Error", "Please fill in all fields")
            return

        conn = connect_to_db()
        if conn is None:
            return

        cursor = conn.cursor()

        try:
            # Query to verify credentials
            query = "SELECT * FROM admins WHERE username = %s AND password = %s"
            cursor.execute(query, (username, password))
            result = cursor.fetchone()

            if result:
                messagebox.showinfo("Login Successful", "Welcome, Admin!")
                admin_options()
            else:
                messagebox.showerror("Login Failed", "Invalid admin credentials")

        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

        finally:
            cursor.close()
            conn.close()

    login_window = tk.Tk()
    login_window.title("Admin Login")
    login_window.configure(bg=BACKGROUND_COLOR)

    tk.Label(login_window, text="Username:", font=FONT_LABEL, bg=BACKGROUND_COLOR, fg=TEXT_COLOR).grid(row=0, column=0, padx=10, pady=10)
    admin_username_entry = tk.Entry(login_window, font=FONT_ENTRY)
    admin_username_entry.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(login_window, text="Password:", font=FONT_LABEL, bg=BACKGROUND_COLOR, fg=TEXT_COLOR).grid(row=1, column=0, padx=10, pady=10)
    admin_password_entry = tk.Entry(login_window, font=FONT_ENTRY, show="*")
    admin_password_entry.grid(row=1, column=1, padx=10, pady=10)

    tk.Button(login_window, text="Login", font=FONT_BUTTON, bg=BUTTON_COLOR, fg=TEXT_COLOR, activebackground=BUTTON_HOVER_COLOR, command=verify_admin).grid(row=2, column=0, columnspan=2, pady=10)

    login_window.mainloop()

# Admin options window (example)
def admin_options():
    options_window = tk.Tk()
    options_window.title("Admin Options")
    options_window.configure(bg=BACKGROUND_COLOR)

    tk.Label(options_window, text="Admin Options", font=FONT_LABEL, bg=BACKGROUND_COLOR, fg=TEXT_COLOR).grid(row=0, column=0, padx=10, pady=10)

    tk.Button(options_window, text="Add Customer", font=FONT_BUTTON, bg=BUTTON_COLOR, fg=TEXT_COLOR, activebackground=BUTTON_HOVER_COLOR, command=add_customer_window).grid(row=1, column=0, padx=10, pady=10)

    options_window.mainloop()

# Add customer window (example)
def add_customer_window():
    add_window = tk.Tk()
    add_window.title("Add Customer")
    add_window.configure(bg=BACKGROUND_COLOR)

    tk.Label(add_window, text="Name:", font=FONT_LABEL, bg=BACKGROUND_COLOR, fg=TEXT_COLOR).grid(row=0, column=0, padx=10, pady=10)
    name_entry = tk.Entry(add_window, font=FONT_ENTRY)
    name_entry.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(add_window, text="Email:", font=FONT_LABEL, bg=BACKGROUND_COLOR, fg=TEXT_COLOR).grid(row=1, column=0, padx=10, pady=10)
    email_entry = tk.Entry(add_window, font=FONT_ENTRY)
    email_entry.grid(row=1, column=1, padx=10, pady=10)

    tk.Button(add_window, text="Add", font=FONT_BUTTON, bg=BUTTON_COLOR, fg=TEXT_COLOR, activebackground=BUTTON_HOVER_COLOR, command=lambda: add_customer(name_entry.get(), email_entry.get())).grid(row=2, column=0, columnspan=2, pady=10)

    add_window.mainloop()

# Run the admin login window
admin_login()

import tkinter as tk
from tkinter import messagebox
import mysql.connector 
from mysql.connector.abstracts import MySQLCursorAbstract


orders = dict()
customer_id_counter = 1


class CityElectronicsApp:
    cursor: MySQLCursorAbstract

    def __init__(self, root):
        self.cursor = None
        self.root = root
        self.root.title("City Electronics Management System")
        self.root.geometry("800x600")
        self.root.configure(bg="#1a1a2e")
        self.customer_cart = {}
        self.init_db()
        self.city_electronics_login_window()

    def init_db(self):
        self.db = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="",
            database="cityelectronics"
        )

        self.cursor = self.db.cursor()

    def city_electronics_login_window(self):
        self.clear_window()
        main_frame = tk.Frame(self.root, bg="#1a1a2e")
        main_frame.pack(expand=True, fill=tk.BOTH)

        tk.Label(main_frame, text="City Electronics Management System", font=("fixedsys", 23, "bold"), fg="black").pack(
            pady=15)
        tk.Button(main_frame, text="Admin Login", command=self.admin_login_window, font=("fixedsys", 20), width=20,
                  bg="#16213e", fg="white").pack(pady=10)
        tk.Button(main_frame, text="Customer Login", command=self.password_customer_login, font=("fixedsys", 20),
                  width=20, bg="#16213e", fg="white").pack(pady=10)
        tk.Button(main_frame, text="Exit", command=self.root.quit, font=("fixedsys", 17), width=20, fg="white",
                  bg="#900c3f").pack(pady=20)

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def admin_login_window(self):
        self.clear_window()
        tk.Label(self.root, text="Admin Login", font=("fixedsys", 19, "bold"), bg="#1a1a2e", fg="white").pack(pady=20)
        tk.Label(self.root, text="Username", font=("Arial", 18), width=20, bg="#16213e", fg="white").pack()
        self.admin_username_entry = tk.Entry(self.root, font=("Arial", 15), width=30)
        self.admin_username_entry.pack(pady=5)
        tk.Label(self.root, text="Password", font=("Arial", 18), width=20, bg="#16213e", fg="white").pack()
        self.admin_password_entry = tk.Entry(self.root, show="*", font=("Arial", 14), width=30)
        self.admin_password_entry.pack(pady=5)
        tk.Button(self.root, text="Login",
                  command=lambda: self.authenticate_admin(self.admin_username_entry, self.admin_password_entry),
                  font=("fixedsys", 16), width=33, bg="#16213e", fg="white").pack(pady=20)
        tk.Button(self.root, text="Exit", command=self.city_electronics_login_window, font=("fixedsys", 14), width=20,
                  bg="#900c3f", fg="white").pack(pady=5)

    def authenticate_admin(self, admin_username_entry, admin_password_entry):
        username = admin_username_entry.get()
        password = admin_password_entry.get()
        if self.db is None:
            messagebox.showerror("Database Connection Error", "Failed to connect to the database.")
            return False
        try:
            query = "SELECT * FROM admins WHERE username = %s AND password = %s"
            self.cursor.execute(query, (username, password))
            result = self.cursor.fetchone()
            if result:
                messagebox.showinfo("Login Successful", "Welcome Admin!")
                self.admin_dashboard()
                return True
            else:
                messagebox.showerror("Login Failed", "Invalid credentials.")
                return False
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", f"Error: {e}")
            return False

    def admin_dashboard(self):
        self.clear_window()
        main_frame = tk.Frame(self.root, bg="#1a1a2e")
        main_frame.pack(expand=True, fill=tk.BOTH)
        tk.Label(main_frame, text="Admin Dashboard", font=("fixedsys", 18, "bold"), bg="#16213e", fg="white").pack(
            pady=20)
        tk.Button(main_frame, text="Add Product", command=self.add_product_window, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=5)
        tk.Button(main_frame, text="Modify Product", command=self.modify_product_window, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=5)
        tk.Button(main_frame, text="Remove Product", command=self.remove_product_window, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=5)
        tk.Button(main_frame, text="View Orders", command=self.view_orders_window, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=5)
        tk.Button(main_frame, text="Logout", command=self.city_electronics_login_window, font=("Arial", 14), width=20,
                  bg="#900c3f", fg="white").pack(pady=5)

    def add_product_window(self):
        self.clear_window()
        tk.Label(self.root, text="Add Product", font=("fixedsys", 18, "bold"), bg="#16213e", fg="white").pack(pady=20)
        tk.Label(self.root, text="Product ID", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_id_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_id_entry.pack(pady=5)
        tk.Label(self.root, text="Product Name", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_name_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_name_entry.pack(pady=5)
        tk.Label(self.root, text="Price", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_price_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_price_entry.pack(pady=5)
        tk.Label(self.root, text="Quantity", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_quantity_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_quantity_entry.pack(pady=5)
        tk.Button(self.root, text="Add Product", command=self.add_product, font=("Arial", 14), width=20, bg="#16213e",
                  fg="white").pack(pady=20)
        tk.Button(self.root, text="Back", command=self.admin_dashboard, font=("Arial", 14), width=20, bg="#900c3f",
                  fg="white").pack(pady=5)

    def add_product(self):
        product_id = self.product_id_entry.get()
        name = self.product_name_entry.get()
        try:
            price = float(self.product_price_entry.get())
            quantity = int(self.product_quantity_entry.get())
            sql = "INSERT INTO products (product_id, name, price, quantity) VALUES (%s, %s, %s, %s)"
            val = (product_id, name, price, quantity)
            self.cursor.execute(sql, val)
            self.db.commit()
            messagebox.showinfo("Success", f"Product '{name}' added successfully.")
            self.admin_dashboard()
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid values.")

    def modify_product_window(self):
        self.clear_window()
        tk.Label(self.root, text="Modify Product", font=("fixedsys", 18, "bold"), bg="#16213e", fg="white").pack(
            pady=20)
        tk.Label(self.root, text="Product ID", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.modify_product_id_entry = tk.Entry(self.root, font=("Arial", 14))
        self.modify_product_id_entry.pack(pady=5)
        tk.Button(self.root, text="Search Product", command=self.search_product, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=10)
        tk.Button(self.root, text="Back", command=self.admin_dashboard, font=("Arial", 14), width=20, bg="#900c3f",
                  fg="white").pack(pady=5)

    def search_product(self):
        product_id = self.modify_product_id_entry.get()
        try:
            sql = "SELECT * FROM products WHERE product_id=%s"
            self.cursor.execute(sql, (product_id,))
            result = self.cursor.fetchone()
            if result:
                product_details = {"name": result[1], "price": result[2], "quantity": result[3]}
                self.show_modify_product_form(product_id, product_details)
            else:
                messagebox.showerror("Product Not Found", f"Product ID '{product_id}' does not exist.")
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")

    def show_modify_product_form(self, product_id, product_details):
        self.clear_window()
        tk.Label(self.root, text="Modify Product Details", font=("fixedsys", 18, "bold"), bg="#16213e",
                 fg="white").pack(pady=20)
        tk.Label(self.root, text="Product ID", font=("Arial", 14, "bold"), bg="#16213e", fg="white").pack()
        tk.Label(self.root, text=product_id, font=("Arial", 14), bg="#16213e", fg="white").pack(pady=5)
        tk.Label(self.root, text="Product Name", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_name_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_name_entry.insert(0, product_details['name'])
        self.product_name_entry.pack(pady=5)
        tk.Label(self.root, text="Price", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_price_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_price_entry.insert(0, product_details['price'])
        self.product_price_entry.pack(pady=5)
        tk.Label(self.root, text="Quantity", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_quantity_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_quantity_entry.insert(0, product_details['quantity'])
        self.product_quantity_entry.pack(pady=5)
        tk.Button(self.root, text="Modify Product", command=lambda: self.modify_product(product_id), font=("Arial", 14),
                  width=20, bg="#16213e", fg="white").pack(pady=20)
        tk.Button(self.root, text="back", command=self.modify_product_window, font=("Arial", 14), width=20,
                  bg="#900c3f", fg="white").pack(pady=20)

    def modify_product(self, product_id):
        name = self.product_name_entry.get()
        try:
            price = float(self.product_price_entry.get())
            quantity = int(self.product_quantity_entry.get())
            sql = "UPDATE products SET name=%s, price=%s, quantity=%s WHERE product_id=%s"
            val = (name, price, quantity, product_id)
            self.cursor.execute(sql, val)
            self.db.commit()
            messagebox.showinfo("Success", f"Product '{name}' updated successfully.")
            self.admin_dashboard()
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid values.")

    def remove_product_window(self):
        self.clear_window()
        tk.Label(self.root, text="Remove Product", font=("Arial", 18, "bold"), bg="#16213e", fg="white").pack(pady=20)
        tk.Label(self.root, text="Product ID", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.remove_product_id_entry = tk.Entry(self.root, font=("Arial", 14))
        self.remove_product_id_entry.pack(pady=5)
        tk.Button(self.root, text="Remove Product", command=self.remove_product, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=20)
        tk.Button(self.root, text="Back", command=self.admin_dashboard, font=("Arial", 14), width=20, bg="#900c3f",
                  fg="white").pack(pady=5)

    def remove_product(self):
        product_id = self.remove_product_id_entry.get()
        try:
            sql = "DELETE FROM products WHERE product_id=%s"
            self.cursor.execute(sql, (product_id,))
            self.db.commit()
            if self.cursor.rowcount > 0:
                messagebox.showinfo("Success", "Product removed successfully.")
                self.admin_dashboard()
            else:
                messagebox.showerror("Product Not Found", f"Product ID '{product_id}' does not exist.")
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")

    def view_orders_window(self):
        self.clear_window()
        main_frame = tk.Frame(self.root, bg="#1a1a2e")
        main_frame.pack(expand=True, fill=tk.BOTH)

        tk.Label(main_frame, text="Customer Orders", font=("Arial", 18, "bold"), bg="#16213e", fg="white").pack(pady=20)

        if not orders:
            tk.Label(main_frame, text="No orders placed yet.", font=("Arial", 14), bg="#16213e", fg="white").pack(
                pady=10)
        else:
            for order_id, order_details in orders.items():
                try:
                    order_text = f"Order ID: {order_id}, Products: {order_details.get('items', 'N/A')}, Total: {order_details.get('total', 'N/A')}"
                    tk.Label(main_frame, text=order_text, font=("Arial", 14), bg="lightblue").pack(pady=5)
                except KeyError as e:
                    tk.Label(main_frame, text=f"Error in order data: Missing key {e}", font=("Arial", 14), bg="#900c3f",
                             fg="white").pack(pady=5)

        tk.Button(main_frame, text="Back", command=self.admin_dashboard, font=("Arial", 14), width=20, bg="#900c3f",
                  fg="white").pack(pady=20)

    def password_customer_login(self):
        self.clear_window()
        tk.Label(self.root, text="Customer Login", font=("fixedsys", 18, "bold"), bg="#16213e", fg="white").pack(
            pady=20)
        tk.Label(self.root, text="Enter your name:", font=("Arial", 15, "bold"), bg="#16213e", fg="white").pack()
        self.customer_name_entry = tk.Entry(self.root, font=("Arial", 14))
        self.customer_name_entry.pack(pady=5)
        tk.Button(self.root, text="Login", command=self.customer_authenticated, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=20)
        tk.Button(self.root, text="back", command=self.city_electronics_login_window, font=("Arial", 14), width=20,
                  bg="#900c3f", fg="white").pack(pady=20)

    def customer_authenticated(self):
        self.current_customer_id = f'customer{self.get_next_customer_id()}'
        customer_name = self.customer_name_entry.get()

        if self.db is None:
            messagebox.showerror("Database Connection Error", "Failed to connect to the database.")
            return False

        try:
            cursor = self.db.cursor()
            query = "INSERT INTO customers (customer_id, customer_name) VALUES (%s, %s)"
            cursor.execute(query, (self.current_customer_id, customer_name))
            self.db.commit()
            messagebox.showinfo("Welcome", f"Welcome, {customer_name}!")
            self.customer_menu_window()
            return True
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", f"Error: {e}")
            return False
        finally:
            if self.db.is_connected():
                cursor.close()
    def get_next_customer_id(self):
        global customer_id_counter
        customer_id = customer_id_counter
        customer_id_counter += 1
        return customer_id

    def customer_menu_window(self):
        self.clear_window()
        tk.Label(self.root, text="Customer Menu", font=("fixedsys", 19, "bold"), bg="#16213e", fg="white").pack(pady=20)
        tk.Button(self.root, text="View Products", command=self.view_products, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=10)
        tk.Button(self.root, text="Add to Cart", command=self.add_to_cart, font=("Arial", 14), width=20, bg="#16213e",
                  fg="white").pack(pady=10)
        tk.Button(self.root, text="View Cart", command=self.view_cart, font=("Arial", 14), width=20, bg="#16213e",
                  fg="white").pack(pady=10)
        tk.Button(self.root, text="Place Order", command=self.place_order, font=("Arial", 14), width=20, bg="#16213e",
                  fg="white").pack(pady=10)
        tk.Button(self.root, text="Logout", command=self.city_electronics_login_window, font=("Arial", 14), width=20,
                  bg="#900c3f", fg="white").pack(pady=10)

    def view_products(self):
        self.clear_window()

        main_frame = tk.Frame(self.root, bg="#1a1a2e")
        main_frame.pack(expand=True, fill=tk.BOTH)

        title_label = tk.Label(main_frame, text="Available Products", font=("fixedsys", 18, "bold"), bg="#16213e",
                               fg="white")
        title_label.pack(pady=20)


        product_frame = tk.Frame(main_frame, bg="#f5f5f5", bd=2, relief=tk.RIDGE)
        product_frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=10)

        try:
            self.cursor.execute("SELECT * FROM products")
            result = self.cursor.fetchall()
            if result:
                for product in result:
                    product_info = f"ID: {product[0]}, Name: {product[1]}, Price: {product[2]}, Quantity: {product[3]}"
                    product_label = tk.Label(product_frame, text=product_info, font=("Arial", 14), bg="#f5f5f5",
                                             fg="#333333", anchor="w")
                    product_label.pack(fill=tk.X, padx=10, pady=5)
            else:
                no_products_label = tk.Label(product_frame, text="No products available.", font=("Arial", 14),
                                             bg="#f5f5f5", fg="#333333", anchor="w")
                no_products_label.pack(fill=tk.X, padx=10, pady=5)
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")


        back_button = tk.Button(main_frame, text="Back", command=self.customer_menu_window, font=("Arial", 14),
                                width=20, bg="#900c3f", fg="white")
        back_button.pack(pady=20)

    def view_cart(self):
        self.clear_window()
        main_frame = tk.Frame(self.root, bg="#1a1a2e")
        main_frame.pack(expand=True, fill=tk.BOTH)

        tk.Label(main_frame, text="Your Cart", font=("fixedsys", 18, "bold"), bg="#16213e", fg="white").pack(pady=20)
        total = 0
        if self.customer_cart:
            for product_id, quantity in self.customer_cart.items():
                sql = "SELECT * FROM products WHERE product_id=%s"
                self.cursor.execute(sql, (product_id,))
                product = self.cursor.fetchone()
                total += quantity * product[2]
                tk.Label(main_frame, text=f"{product[1]} - {quantity} x {product[2]}", font=("Arial", 14)).pack(pady=5)
            tk.Label(main_frame, text=f"Total: {total}", font=("Arial", 14)).pack(pady=10)
        else:
            tk.Label(main_frame, text="Your cart is empty.", font=("Arial", 14)).pack(pady=5)

        tk.Button(main_frame, text="Back", command=self.customer_menu_window, font=("Arial", 14), width=20,
                  bg="#900c3f", fg="white").pack(pady=20)

    def add_to_cart(self):
        self.clear_window()
        tk.Label(self.root, text="Add to Cart", font=("fixedsys", 18, "bold"), bg="#16213e", fg="white").pack(pady=20)
        tk.Label(self.root, text="Enter Product ID", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_id_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_id_entry.pack(pady=5)
        tk.Label(self.root, text="Enter Quantity", font=("Arial", 14), bg="#16213e", fg="white").pack()
        self.product_quantity_entry = tk.Entry(self.root, font=("Arial", 14))
        self.product_quantity_entry.pack(pady=5)
        tk.Button(self.root, text="Add to Cart", command=self.add_product_to_cart, font=("Arial", 14), width=20,
                  bg="#16213e", fg="white").pack(pady=20)
        tk.Button(self.root, text="Back", command=self.customer_menu_window, font=("Arial", 14), width=20, bg="#900c3f",
                  fg="white").pack(pady=10)

    def add_product_to_cart(self):
        product_id = self.product_id_entry.get()
        try:
            quantity = int(self.product_quantity_entry.get())
            sql = "SELECT * FROM products WHERE product_id=%s"
            self.cursor.execute(sql, (product_id,))
            product = self.cursor.fetchone()
            if product and quantity <= product[3]:
                self.customer_cart[product_id] = self.customer_cart.get(product_id, 0) + quantity
                messagebox.showinfo("Cart", f"Added {quantity} of {product[1]} to your cart.")  # product[1] is the name
            else:
                messagebox.showerror("Error", "Invalid product ID or insufficient stock.")
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid quantity.")

    def view_cart(self):
        self.clear_window()
        tk.Label(self.root, text="Your Cart", font=("fixedsys", 18, "bold"), bg="#16213e", fg="white").pack(pady=20)
        total = 0
        if self.customer_cart:
            for product_id, quantity in self.customer_cart.items():
                sql = "SELECT * FROM products WHERE product_id=%s"
                self.cursor.execute(sql, (product_id,))
                product = self.cursor.fetchone()
                total += quantity * product[2]
                tk.Label(self.root, text=f"{product[1]} - {quantity} x {product[2]}", font=("Arial", 14)).pack(pady=5)
            tk.Label(self.root, text=f"Total: {total}", font=("Arial", 14)).pack(pady=10)
        else:
            tk.Label(self.root, text="Your cart is empty.", font=("Arial", 14)).pack(pady=5)
        tk.Button(self.root, text="Back", command=self.customer_menu_window, font=("Arial", 14), width=20, bg="#900c3f",
                  fg="white").pack(pady=20)

    def place_order(self):
        if not self.customer_cart:
            messagebox.showerror("Error", "Your cart is empty!")
        else:
            total = 0
            try:
                for product_id, quantity in self.customer_cart.items():
                    self.cursor.execute("SELECT price FROM products WHERE product_id=%s", (product_id,))
                    product = self.cursor.fetchone()
                    if product:
                        total += quantity * product[0]
                    else:
                        messagebox.showerror("Error", f"Product ID '{product_id}' not found in database.")
                        return


                order_query = "INSERT INTO orders (customer_id,created_at, total) VALUES (%s, %s, %s)"
                cart_details = str(self.customer_cart)
                self.cursor.execute(order_query, (self.current_customer_id, cart_details, total))
                self.db.commit()


                self.customer_cart = {}
                messagebox.showinfo("Order Placed", f"Your order has been placed successfully!\nTotal: {total}")
                self.customer_menu_window()

            except mysql.connector.Error as err:
                messagebox.showerror("Database Error", f"Error: {err}")
            except ValueError:
                messagebox.showerror("Invalid Input", "Please enter valid values.")


root = tk.Tk()
app = CityElectronicsApp(root)
root.mainloop()

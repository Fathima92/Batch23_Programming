import tkinter as tk
from tkinter import messagebox
import mysql.connector
from mysql.connector import Error

class CityElectronicsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("City Electronics")
        self.root.geometry("800x600")

        # Connect to MySQL database
        self.db = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="",
            database="CityElectronics"
        )
        self.cursor = self.db.cursor()

        self.cart = []

        self.main_menu()

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def main_menu(self):
        self.clear_screen()
        tk.Label(self.root, text="Welcome to City Electronics").pack()
        tk.Button(self.root, text="Admin Login", command=self.admin_login).pack()
        tk.Button(self.root, text="Customer Login", command=self.customer_login).pack()

    def admin_login(self):
        self.clear_screen()
        tk.Label(self.root, text="Admin Login").pack()
        tk.Label(self.root, text="Username").pack()
        self.admin_username_entry = tk.Entry(self.root)
        self.admin_username_entry.pack()
        tk.Label(self.root, text="Password").pack()
        self.admin_password_entry = tk.Entry(self.root, show='*')
        self.admin_password_entry.pack()
        tk.Button(self.root, text="Login", command=self.authenticate_admin).pack()

    def authenticate_admin(self):
        username = self.admin_username_entry.get()
        password = self.admin_password_entry.get()

        try:
            if self.db.is_connected():
                self.cursor = self.db.cursor(dictionary=True)
                query = "SELECT * FROM admins WHERE username = %s AND password = %s"
                self.cursor.execute(query, (username, password))
                admin = self.cursor.fetchone()

                if admin:
                    self.admin_dashboard()
                else:
                    messagebox.showerror("Error", "Invalid Credentials")
                    self.main_menu()
        except Error as e:
            messagebox.showerror("Error", f"Error connecting to database: {e}")
        finally:
            if self.db.is_connected():
                self.cursor.close()
                self.db.close()

    def admin_dashboard(self):
        self.clear_screen()
        tk.Label(self.root, text="Admin Dashboard").pack()


    def admin_dashboard(self):
        self.clear_screen()
        tk.Label(self.root, text="Admin Dashboard").pack()
        tk.Button(self.root, text="Add Product", command=self.add_product).pack()
        tk.Button(self.root, text="Modify Product", command=self.modify_product).pack()
        tk.Button(self.root, text="Remove Product", command=self.remove_product).pack()
        tk.Button(self.root, text="View Products", command=self.view_products).pack()
        tk.Button(self.root, text="Back", command=self.main_menu).pack()

    def add_product(self):
        self.clear_screen()
        tk.Label(self.root, text="Add Product").pack()
        tk.Label(self.root, text="Product Name").pack()
        self.product_name_entry = tk.Entry(self.root)
        self.product_name_entry.pack()
        tk.Label(self.root, text="Product Price").pack()
        self.product_price_entry = tk.Entry(self.root)
        self.product_price_entry.pack()
        tk.Label(self.root, text="Product Quantity").pack()
        self.product_quantity_entry = tk.Entry(self.root)
        self.product_quantity_entry.pack()
        tk.Button(self.root, text="Add", command=self.save_product).pack()
        tk.Button(self.root, text="Back", command=self.admin_dashboard).pack()

    def save_product(self):
        name = self.product_name_entry.get()
        price = float(self.product_price_entry.get())
        quantity = int(self.product_quantity_entry.get())
        self.cursor.execute("INSERT INTO products (name, price, quantity) VALUES (%s, %s, %s)", (name, price, quantity))
        self.db.commit()
        messagebox.showinfo("Success", "Product added successfully")
        self.admin_dashboard()

    def modify_product(self):
        self.clear_screen()
        tk.Label(self.root, text="Modify Product").pack()
        tk.Label(self.root, text="Product ID").pack()
        self.product_id_entry = tk.Entry(self.root)
        self.product_id_entry.pack()
        tk.Label(self.root, text="New Product Name").pack()
        self.new_product_name_entry = tk.Entry(self.root)
        self.new_product_name_entry.pack()
        tk.Label(self.root, text="New Product Price").pack()
        self.new_product_price_entry = tk.Entry(self.root)
        self.new_product_price_entry.pack()
        tk.Label(self.root, text="New Product Quantity").pack()
        self.new_product_quantity_entry = tk.Entry(self.root)
        self.new_product_quantity_entry.pack()
        tk.Button(self.root, text="Modify", command=self.update_product).pack()
        tk.Button(self.root, text="Back", command=self.admin_dashboard).pack()

    def update_product(self):
        product_id = int(self.product_id_entry.get())
        new_name = self.new_product_name_entry.get()
        new_price = float(self.new_product_price_entry.get())
        new_quantity = int(self.new_product_quantity_entry.get())
        self.cursor.execute("UPDATE products SET name=%s, price=%s, quantity=%s WHERE id=%s", (new_name, new_price, new_quantity, product_id))
        self.db.commit()
        messagebox.showinfo("Success", "Product modified successfully")
        self.admin_dashboard()

    def remove_product(self):
        self.clear_screen()
        tk.Label(self.root, text="Remove Product").pack()
        tk.Label(self.root, text="Product ID").pack()
        self.product_id_entry = tk.Entry(self.root)
        self.product_id_entry.pack()
        tk.Button(self.root, text="Remove", command=self.delete_product).pack()
        tk.Button(self.root, text="Back", command=self.admin_dashboard).pack()

    def delete_product(self):
        product_id = int(self.product_id_entry.get())
        self.cursor.execute("DELETE FROM products WHERE id=%s", (product_id,))
        self.db.commit()
        messagebox.showinfo("Success", "Product removed successfully")
        self.admin_dashboard()

    def view_products(self):
        self.clear_screen()
        tk.Label(self.root, text="Product List").pack()
        self.cursor.execute("SELECT * FROM products")
        products = self.cursor.fetchall()
        for product in products:
            tk.Label(self.root, text=f"ID: {product[0]}, Name: {product[1]}, Price: ${product[2]}, Quantity: {product[3]}").pack()
        tk.Button(self.root, text="Back", command=self.admin_dashboard).pack()

    def customer_login(self):
        self.clear_screen()
        tk.Label(self.root, text="Customer Login").pack()
        tk.Label(self.root, text="Username").pack()
        self.customer_username_entry = tk.Entry(self.root)
        self.customer_username_entry.pack()
        tk.Label(self.root, text="Password").pack()
        self.customer_password_entry = tk.Entry(self.root, show='*')
        self.customer_password_entry.pack()
        tk.Button(self.root, text="Login", command=self.authenticate_customer).pack()

    def authenticate_customer(self):
        username = self.customer_username_entry.get()
        password = self.customer_password_entry.get()

        try:
            if self.db.is_connected():
                self.cursor = self.db.cursor(dictionary=True)
                query = "SELECT * FROM customers WHERE username = %s AND password = %s"
                self.cursor.execute(query, (username, password))
                customer = self.cursor.fetchone()

                if customer:
                    self.browse_products()
                else:
                    messagebox.showerror("Error", "Invalid Credentials")
                    self.main_menu()
        except Error as e:
            messagebox.showerror("Error", f"Error connecting to database: {e}")
        finally:
            if self.db.is_connected():
                self.cursor.close()
                self.db.close()

    def browse_products(self):
        self.clear_screen()
        tk.Label(self.root, text="Product Catalog").pack()
        self.cursor.execute("SELECT * FROM products")
        products = self.cursor.fetchall()
        for product in products:
            tk.Label(self.root, text=f"ID: {product[0]}, Name: {product[1]}, Price: ${product[2]}, Quantity: {product[3]}").pack()
        tk.Button(self.root, text="Add Product to Cart", command=self.add_to_cart).pack()
        tk.Button(self.root, text="Place Order", command=self.place_order).pack()
        tk.Button(self.root, text="Back", command=self.main_menu).pack()

    def add_to_cart(self):
        self.clear_screen()
        tk.Label(self.root, text="Add Product to Cart").pack()
        tk.Label(self.root, text="Product ID").pack()
        self.product_id_entry = tk.Entry(self.root)
        self.product_id_entry.pack()
        tk.Label(self.root, text="Quantity").pack()
        self.product_quantity_entry = tk.Entry(self.root)
        self.product_quantity_entry.pack()
        tk.Button(self.root, text="Add", command=self.save_to_cart).pack()
        tk.Button(self.root, text="Back", command=self.browse_products).pack()

    def save_to_cart(self):
        product_id = int(self.product_id_entry.get())
        quantity = int(self.product_quantity_entry.get())
        self.cursor.execute("SELECT name FROM products WHERE id=%s", (product_id,))
        product_name = self.cursor.fetchone()[0]
        self.cart.append({'product': product_name, 'quantity': quantity})
        messagebox.showinfo("Success", "Product added to cart")
        self.browse_products()

    def place_order(self):
        self.clear_screen()
        total_amount = 0
        for item in self.cart:
            self.cursor.execute("SELECT price FROM products WHERE name=%s", (item['product'],))
            price = self.cursor.fetchone()[0]
            total_amount += price * item['quantity']
        tk.Label(self.root, text=f"Total Payment Amount: ${total_amount}").pack()
        tk.Button(self.root, text="Place Order", command=self.order_placed).pack()
        tk.Button(self.root, text="Back", command=self.browse_products).pack()

    def order_placed(self):
        total_amount = 0
        for item in self.cart:
            self.cursor.execute("SELECT id, price, quantity FROM products WHERE name=%s", (item['product'],))
            product_id, price, stock = self.cursor.fetchone()
            total_amount += price * item['quantity']
            new_quantity = stock - item['quantity']
            self.cursor.execute("UPDATE products SET quantity=%s WHERE id=%s", (new_quantity, product_id))
        self.db.commit()
        messagebox.showinfo("Success", f"Order placed successfully. Total: ${total_amount}")
        self.cart.clear()
        self.main_menu()

if __name__ == "__main__":
    root = tk.Tk()
    app = CityElectronicsApp(root)
    root.mainloop()

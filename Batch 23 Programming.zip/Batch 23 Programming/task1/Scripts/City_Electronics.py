import tkinter as tk
from tkinter import messagebox
from tkinter import font as tkfont
from tkinter import ttk
import pyodbc

def connect_db():
    try:
        conn = pyodbc.connect('DRIVER={SQL Server};'
                              'SERVER=AFRIN_ALI;'
                              'DATABASE=City_Elelctronics;'
                              'Trusted_Connection=yes;')
        return conn
    except pyodbc.Error as e:
        messagebox.showerror("Database Error", str(e))
        return None

def validate_user(username, password, role):
    conn = connect_db()
    if conn is None:
        return False
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Login WHERE Username = ? AND Password = ? AND Role = ?", (username, password, role))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result is not None

def add_product(product_name, price, description):
    if not product_name or not price or not description:
        messagebox.showwarning("Input Error", "Please fill all fields.")
        return
    try:
        price = float(price)  
        conn = connect_db()
        if conn is None:
            return
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Products (ProductName, Price, Description) VALUES (?, ?, ?)", (product_name, price, description))
        conn.commit()
        cursor.close()
        conn.close()
        messagebox.showinfo("Success", "Product added successfully!")
    except ValueError:
        messagebox.showerror("Input Error", "Please enter a valid price.")
    except pyodbc.Error as e:
        messagebox.showerror("Database Error", str(e))

def fetch_products():
    conn = connect_db()
    if conn is None:
        return []
    cursor = conn.cursor()
    cursor.execute("SELECT ProductID, ProductName, Price, Description FROM Products")
    products = cursor.fetchall()
    cursor.close()
    conn.close()
    return products

def display_products():
    products = fetch_products()
    if not products:
        messagebox.showinfo("No Products", "No products available.")
        return
    
    product_window = tk.Toplevel(root)
    product_window.title("Available Products")
    product_window.geometry("600x400")

    tree = ttk.Treeview(product_window, columns=("ProductID", "ProductName", "Price", "Description"), show='headings')
    
    tree.heading("ProductID", text="Product ID")
    tree.heading("ProductName", text="Product Name")
    tree.heading("Price", text="Price")
    tree.heading("Description", text="Description")

    tree.column("ProductID", width=100, anchor='center')
    tree.column("ProductName", width=200, anchor='center')
    tree.column("Price", width=100, anchor='center')
    tree.column("Description", width=200, anchor='center')

    for product_id, product_name, price, description in products:
        tree.insert("", tk.END, values=(product_id, product_name, f"${price:.2f}", description))

    scrollbar = tk.Scrollbar(product_window, orient="vertical", command=tree.yview)
    
    tree.configure(yscroll=scrollbar.set)

    tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

def show_login_window():
   entry_username.delete(0, tk.END) 
   entry_password.delete(0, tk.END) 
   admin_login_var.set(False)  
   customer_login_var.set(False)  
   root.deiconify()  

def create_dashboard(title, welcome_message, is_admin=False):
   dashboard_window = tk.Tk()
   dashboard_window.title(title)
   
   dashboard_window.geometry("600x550") 
   dashboard_window.config(bg="#F7F9FC")
   
   tk.Label(dashboard_window, text=welcome_message, font=title_font, bg="#F7F9FC", fg="#2C3E50").pack(pady=20)

   if is_admin:  
       tk.Button(dashboard_window,
                 text="View Products",
                 command=display_products,
                 bg="#1ABC9C", fg="white").pack(pady=(10))

       tk.Label(dashboard_window, text="Add Product", font=label_font, bg="#F7F9FC").pack(pady=10)
       
       tk.Label(dashboard_window, text="Product Name:", font=label_font, bg="#F7F9FC").pack(pady=5)
       product_name_entry = tk.Entry(dashboard_window)
       product_name_entry.pack(pady=5)

       tk.Label(dashboard_window, text="Price:", font=label_font, bg="#F7F9FC").pack(pady=5)
       price_entry = tk.Entry(dashboard_window)
       price_entry.pack(pady=5)

       tk.Label(dashboard_window, text="Description:", font=label_font, bg="#F7F9FC").pack(pady=5)
       description_entry = tk.Entry(dashboard_window)
       description_entry.pack(pady=5)

       tk.Button(dashboard_window,
                 text="Add Product",
                 command=lambda: add_product(product_name_entry.get(), price_entry.get(), description_entry.get()),
                 bg="#1ABC9C", fg="white").pack(pady=(10))

   else:
       tk.Button(dashboard_window,
                 text="View Products",
                 command=display_products,
                 bg="#1ABC9C", fg="white").pack(pady=(10))

   tk.Button(dashboard_window,
             text="Back to Login",
             command=lambda: [dashboard_window.destroy(), show_login_window()],
             bg="#E74C3C", fg="white").pack(pady=(20))

def login():
   username = entry_username.get().strip()
   password = entry_password.get().strip()

   if not username or not password:
       messagebox.showwarning("Input Error", "Please enter both username and password.")
       return

   if admin_login_var.get():
       if validate_user(username, password, 'admin'):
           messagebox.showinfo("Login Success", f"Welcome Admin {username}!")
           root.withdraw()  
           create_dashboard("Admin Dashboard", f"Welcome {username} to the Admin Dashboard", is_admin=True)
       else:
           messagebox.showerror("Login Failed", "Invalid admin username or password.")
   
   elif customer_login_var.get():
       if validate_user(username, password, 'customer'):
           messagebox.showinfo("Login Success", f"Welcome Customer {username}!")
           root.withdraw() 
           create_dashboard("Customer Dashboard", f"Welcome {username} to Customer Dashboard")
       else:
           messagebox.showerror("Login Failed", "Invalid customer username or password.")

root = tk.Tk()
root.title("City Electronics Management System")
root.geometry("500x450")
root.config(bg="#2C3E50")

title_font = tkfont.Font(family="Arial", size=18, weight="bold")
label_font = tkfont.Font(family="Arial", size=12)

login_window = tk.Frame(root, bg="#34495E")
login_window.pack(pady=30, padx=20)

tk.Label(login_window,
         text="City Electronics Login",
         font=title_font,
         fg="#ECF0F1",
         bg="#34495E").grid(row=0,columnspan=2,pady=20)

tk.Label(login_window,
         text="Username:",
         font=label_font,
         fg="#ECF0F1",
         bg="#34495E").grid(row=1,column=0,padx=10,pady=10 ,sticky='e')

entry_username = tk.Entry(login_window,font=label_font)
entry_username.grid(row=1,column=1,pady=5)

tk.Label(login_window,
         text="Password:",
         font=label_font,
         fg="#ECF0F1",
         bg="#34495E").grid(row=2,column=0,padx=10,pady=10 ,sticky='e')

entry_password = tk.Entry(login_window ,show="*", font=label_font)
entry_password.grid(row=2,column=1,pady=5)

admin_login_var = tk.BooleanVar()
customer_login_var = tk.BooleanVar()

tk.Checkbutton(login_window,
               text="Admin Login",
               variable=admin_login_var,
               bg="#34495E",
               fg="#ECF0F1").grid(row=3,columnspan=2)

tk.Checkbutton(login_window,
               text="Customer Login",
               variable=customer_login_var,
               bg="#34495E",
               fg="#ECF0F1").grid(row=4,columnspan=2)

tk.Button(login_window,
          text="Login",
          bg="#1ABC9C",
          fg="white",
          command=login).grid(row=5,columnspan=2,pady=(20))

root.mainloop()

import pyodbc

try:
    conn = pyodbc.connect('DRIVER={SQL Server};SERVER=AFRIN_ALI;DATABASE=City_Electronics;Trusted_Connection=yes;')
    print("Connection successful!")
    conn.close()
except Exception as e:
    print("Connection failed:", e)

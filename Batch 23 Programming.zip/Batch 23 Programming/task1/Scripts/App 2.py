import tkinter as tk
from tkinter import messagebox, simpledialog
import mysql.connector
from mysql.connector import Error

def connect_to_db():
    try:
        connection = mysql.connector.connect(
            host="127.0.0.1",
            user="root",  # Replace with your MySQL username
            password="",  # Replace with your MySQL password
            database="cityelectronicemanagment"  # Replace with your database name
        )
        if connection.is_connected():
            return connection
    except Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")
        return None

def clear_window():
    """Clear the window content."""
    for widget in root.winfo_children():
        widget.destroy()

def logout():
    """Logout the user and show a message."""
    messagebox.showinfo("Logout", "You have been logged out.")
    main_login_window()

def update_product_list(listbox):
    """Update the Listbox with the products from the database."""
    connection = connect_to_db()
    if connection:
        cursor = connection.cursor()
        listbox.delete(0, tk.END)
        cursor.execute("SELECT name FROM products")
        for (name,) in cursor.fetchall():
            listbox.insert(tk.END, name)
        cursor.close()
        connection.close()
    else:
        messagebox.showerror("Error", "Unable to connect to the database")

def admin_login_window():
    """Display the admin login window."""
    clear_window()
    admin_frame = tk.Frame(root, bg='Navy')
    admin_frame.place(relx=0.5, rely=0.5, anchor='center')

    tk.Label(admin_frame, text="Admin Login", font=("Arial", 45), bg='Navy', fg='white').grid(row=0, column=1, columnspan=2, padx=10)
    tk.Label(admin_frame, text="Username:", font=("Arial", 15), bg='Navy', fg='white').grid(row=1, column=0, pady=10)
    tk.Label(admin_frame, text="Password:", font=("Arial", 15), bg='Navy', fg='white').grid(row=2, column=0, pady=10)

    username_entry = tk.Entry(admin_frame, font=("Arial", 15))
    username_entry.grid(row=1, column=1, pady=10)
    password_entry = tk.Entry(admin_frame, font=("Arial", 15), show='*')
    password_entry.grid(row=2, column=1, pady=10)

    def login():
        """Handle admin login."""
        username = username_entry.get()
        password = password_entry.get()

        connection = connect_to_db()
        if connection:
            cursor = connection.cursor(dictionary=True)
            query = "SELECT * FROM admins WHERE username = %s AND password = %s"
            cursor.execute(query, (username, password))
            admin = cursor.fetchone()

            if admin:
                admin_dashboard()
            else:
                messagebox.showerror("Login Failed", "Invalid credentials")

            cursor.close()
            connection.close()
        else:
            messagebox.showerror("Error", "Unable to connect to the database")

    tk.Button(admin_frame, text="Login", font=("Arial", 15), bg='Gold', bd=4, command=login).grid(row=3, column=1, pady=20)
    tk.Button(admin_frame, text="Logout", font=("Arial", 15), bg='Gold', bd=4, command=logout).grid(row=4, column=1, pady=6)

def main_login_window():
    clear_window()
    tk.Label(root, text="Welcome to City Electronics", font=("Arial", 45)).pack(pady=20)
    tk.Button(root, text="Admin Login", font=("Arial", 20), command=admin_login_window).pack(pady=10)
    tk.Button(root, text="Customer Login", font=("Arial", 20), command=customer_login_window).pack(pady=10)

def customer_login_window():
    clear_window()
    # Add customer login window implementation here

def admin_dashboard():
    """Display the admin dashboard."""
    clear_window()
    admin_frame = tk.Frame(root, bg='Navy')
    admin_frame.place(relx=0.5, rely=0.5, anchor='center')

    tk.Label(admin_frame, text="Admin Dashboard", font=("Arial", 45), bg='Navy', fg='white').grid(row=0, column=1, columnspan=2, padx=10)

    def add_product():
        """Add a new product."""
        product_name = simpledialog.askstring("Input", "Enter the product name:")
        if product_name:
            connection = connect_to_db()
            if connection:
                cursor = connection.cursor()
                cursor.execute("INSERT INTO products (name) VALUES (%s)", (product_name,))
                connection.commit()
                cursor.close()
                connection.close()
                update_product_list(product_list)
            else:
                messagebox.showerror("Error", "Unable to connect to the database")

    def update_product():
        """Update an existing product."""
        product_name = simpledialog.askstring("Input", "Enter the product name to modify:")
        connection = connect_to_db()
        if connection:
            cursor = connection.cursor()
            cursor.execute("SELECT id FROM products WHERE name = %s", (product_name,))
            result = cursor.fetchone()
            if result:
                new_name = simpledialog.askstring("Input", "Enter the new product name:")
                if new_name:
                    cursor.execute("UPDATE products SET name = %s WHERE id = %s", (new_name, result[0]))
                    connection.commit()
                    update_product_list(product_list)
            else:
                messagebox.showerror("Error", "Product not found")
            cursor.close()
            connection.close()
        else:
            messagebox.showerror("Error", "Unable to connect to the database")

    def delete_product():
        """Delete a product."""
        product_name = simpledialog.askstring("Input", "Enter the product name to remove:")
        connection = connect_to_db()
        if connection:
            cursor = connection.cursor()
            cursor.execute("DELETE FROM products WHERE name = %s", (product_name,))
            connection.commit()
            cursor.close()
            connection.close()
            update_product_list(product_list)
        else:
            messagebox.showerror("Error", "Unable to connect to the database")

    tk.Button(admin_frame, text="Add Product", font=("Arial", 15), bg='Gold', bd=4, command=add_product).grid(row=1, column=1, pady=10)
    tk.Button(admin_frame, text="Update Product", font=("Arial", 15), bg='Gold', bd=4, command=update_product).grid(row=2, column=1, pady=10)
    tk.Button(admin_frame, text="Delete Product", font=("Arial", 15), bg='Gold', bd=4, command=delete_product).grid(row=3, column=1, pady=10)
    tk.Button(admin_frame, text="Logout", font=("Arial", 15), bg='Gold', bd=4, command=logout).grid(row=4, column=1, pady=10)

    product_list = tk.Listbox(admin_frame, font=("Arial", 15))
    product_list.grid(row=1, column=2, rowspan=4, padx=10, pady=10)
    update_product_list(product_list)

root = tk.Tk()
root.title("City Electronics Management System")
root.geometry("800x600")

main_login_window()
root.mainloop()

import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector


def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="City Electronics"
    )

class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Dashboard System")
        self.geometry("800x600")
        self.frames = {}

        for Page in (LoginPage, AdminDashboard, CustomerDashboard, ProductPage):
            page_name = Page.__name__
            frame = Page(parent=self, controller=self)
            self.frames[page_name] = frame
            frame.place(relwidth=1, relheight=1)

        self.show_frame("LoginPage")

    def show_frame(self, page_name, user_type=None):
        """Display the specified frame."""
        frame = self.frames[page_name]
        if page_name == "ProductPage" and user_type is not None:
            frame.update_view(user_type)
        frame.tkraise()

class LoginPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="Login", font=("Arial", 24)).pack(pady=20)

        tk.Label(self, text="Select Role:").pack(pady=5)
        self.role_var = tk.StringVar()
        self.role_var.set("Select Role")
        role_options = ["Admin", "Customer"]
        self.role_dropdown = ttk.Combobox(self, textvariable=self.role_var, values=role_options, state="readonly")
        self.role_dropdown.pack(pady=5)

        tk.Label(self, text="Username:").pack(pady=5)
        self.username_entry = tk.Entry(self)
        self.username_entry.pack(pady=5)

        tk.Label(self, text="Password:").pack(pady=5)
        self.password_entry = tk.Entry(self, show="*")
        self.password_entry.pack(pady=5)

        tk.Button(self, text="Login", command=self.login).pack(pady=20)

    def login(self):
        selected_role = self.role_var.get()
        username = self.username_entry.get()
        password = self.password_entry.get()

        if selected_role == "Select Role":
            messagebox.showerror("Role Selection", "Please select a role!")
            return

        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)

            if selected_role == "Admin":
                cursor.execute("SELECT * FROM admin WHERE Username=%s AND PasswordHash=%s", (username, password))
            elif selected_role == "Customer":
                cursor.execute("SELECT * FROM users WHERE Username=%s AND PasswordHash=%s", (username, password))

            user = cursor.fetchone()
            conn.close()

            if user:
                if selected_role == "Admin":
                    self.controller.show_frame("AdminDashboard")
                elif selected_role == "Customer":
                    self.controller.show_frame("CustomerDashboard")
            else:
                messagebox.showerror("Login Failed", "Invalid username or password for selected role!")
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

class AdminDashboard(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="Admin Dashboard", font=("Arial", 24)).pack(pady=20)

        tk.Button(self, text="Product Management", command=self.open_product_management).pack(pady=20)

        tk.Button(self, text="View Products", command=lambda: controller.show_frame("ProductPage", "admin")).pack(pady=10)

        tk.Button(self, text="Logout", command=lambda: controller.show_frame("LoginPage")).pack(pady=10)

    def open_product_management(self):
        """Open the Product Management window."""
        ProductManagementWindow(self.controller)

class ProductManagementWindow(tk.Toplevel):
        def __init__(self, controller):
            super().__init__()
            self.controller = controller
            self.title("Product Management")
            self.geometry("400x400")

            tk.Label(self, text="Product Management", font=("Arial", 18)).pack(pady=10)

            tk.Label(self, text="Add a Product").pack(pady=5)
            self.add_product_name_entry = tk.Entry(self)
            self.add_product_name_entry.pack(pady=5)

            tk.Label(self, text="Product Price").pack(pady=5)
            self.add_product_price_entry = tk.Entry(self)
            self.add_product_price_entry.pack(pady=5)

            tk.Button(self, text="Add Product", command=self.add_product).pack(pady=10)

            tk.Label(self, text="Modify a Product").pack(pady=10)
            tk.Label(self, text="Enter Product Name:").pack(pady=5)
            self.modify_name_entry = tk.Entry(self)
            self.modify_name_entry.pack(pady=5)

            tk.Label(self, text="Enter New Price:").pack(pady=5)
            self.modify_price_entry = tk.Entry(self)
            self.modify_price_entry.pack(pady=5)

            tk.Button(self, text="Update Product Price", command=self.modify_product).pack(pady=10)

            tk.Label(self, text="Remove a Product").pack(pady=10)
            tk.Label(self, text="Enter Product Name to Remove:").pack(pady=5)
            self.remove_name_entry = tk.Entry(self)
            self.remove_name_entry.pack(pady=5)

            tk.Button(self, text="Remove Product", command=self.remove_product).pack(pady=10)

        def add_product(self):
            product_name = self.add_product_name_entry.get()
            product_price = self.add_product_price_entry.get()
            if product_name and product_price:
                try:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("INSERT INTO products (ProductName, ProductPrice) VALUES (%s, %s)",
                                   (product_name, product_price))
                    conn.commit()
                    conn.close()
                    messagebox.showinfo("Success", f"Product '{product_name}' added successfully!")
                    self.add_product_name_entry.delete(0, tk.END)
                    self.add_product_price_entry.delete(0, tk.END)
                except mysql.connector.Error as err:
                    messagebox.showerror("Database Error", f"Error: {err}")
            else:
                messagebox.showerror("Error", "Please fill in both fields!")

        def modify_product(self):
            product_name = self.modify_name_entry.get()
            new_price = self.modify_price_entry.get()
            if product_name and new_price:
                try:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE products SET ProductPrice=%s WHERE ProductName=%s",
                                   (new_price, product_name))
                    conn.commit()
                    conn.close()

                    if cursor.rowcount > 0:
                        messagebox.showinfo("Success", f"Price of '{product_name}' updated to ${new_price}!")
                    else:
                        messagebox.showerror("Error", f"Product '{product_name}' not found!")

                    self.modify_name_entry.delete(0, tk.END)
                    self.modify_price_entry.delete(0, tk.END)
                except mysql.connector.Error as err:
                    messagebox.showerror("Database Error", f"Error: {err}")
            else:
                messagebox.showerror("Error", "Please fill in both fields!")

        def remove_product(self):
            product_name = self.remove_name_entry.get()
            if product_name:
                try:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("DELETE FROM products WHERE ProductName=%s", (product_name,))
                    conn.commit()
                    conn.close()

                    if cursor.rowcount > 0:
                        messagebox.showinfo("Success", f"Product '{product_name}' removed successfully!")
                    else:
                        messagebox.showerror("Error", f"Product '{product_name}' not found!")

                    self.remove_name_entry.delete(0, tk.END)
                except mysql.connector.Error as err:
                    messagebox.showerror("Database Error", f"Error: {err}")
            else:
                messagebox.showerror("Error", "Please enter the product name to remove!")

class ProductPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.user_type = None

        self.title_label = tk.Label(self, text="", font=("Arial", 24))
        self.title_label.pack(pady=20)

        self.product_list = tk.Text(self, height=20, width=80)
        self.product_list.pack(pady=20)

        tk.Button(self, text="Back", command=self.go_back).pack(pady=20)

    def update_view(self, user_type):
        """Update product list based on user type."""
        self.user_type = user_type
        self.title_label.config(text="Products List" if user_type == "customer" else "Manage Products")

        self.product_list.delete(1.0, tk.END)
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM products")
            products = cursor.fetchall()
            conn.close()

            if products:
                for product in products:
                    self.product_list.insert(tk.END, f"Product: {product['ProductName']}, Price: ${product['ProductPrice']}\n")
            else:
                self.product_list.insert(tk.END, "No products available.\n")
        except mysql.connector.Error as err:
            self.product_list.insert(tk.END, f"Error: {err}\n")

    def go_back(self):
        if self.user_type == "admin":
            self.controller.show_frame("AdminDashboard")
        elif self.user_type == "customer":
            self.controller.show_frame("CustomerDashboard")

class CustomerDashboard(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        tk.Label(self, text="Customer Dashboard", font=("Arial", 24)).pack(pady=20)

        tk.Button(self, text="View Products", command=lambda: controller.show_frame("ProductPage", "customer")).pack(
            pady=20)

        tk.Label(self, text="Order Product").pack(pady=10)
        self.order_entry = tk.Entry(self)
        self.order_entry.pack(pady=5)

        tk.Label(self, text="Quantity").pack(pady=5)
        self.quantity_entry = tk.Entry(self)
        self.quantity_entry.pack(pady=5)

        tk.Button(self, text="Order Product", command=self.order_product).pack(pady=5)

        tk.Button(self, text="Logout", command=lambda: controller.show_frame("LoginPage")).pack(pady=20)

    def order_product(self):
        product_name = self.order_entry.get()
        quantity = self.quantity_entry.get()

        if product_name and quantity.isdigit():
            quantity = int(quantity)
            try:
                conn = get_db_connection()
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM products WHERE ProductName=%s", (product_name,))
                product = cursor.fetchone()
                conn.close()

                if product:
                    total_price = product['ProductPrice'] * quantity
                    messagebox.showinfo("Order Placed", f"Order successful! Total price: ${total_price}")
                else:
                    messagebox.showerror("Error", f"Product '{product_name}' not found!")
            except mysql.connector.Error as err:
                messagebox.showerror("Database Error", f"Error: {err}")
        else:
            messagebox.showerror("Error", "Please enter valid product name and quantity!")

if __name__ == "__main__":
    app = Application()
    app.mainloop()

import tkinter as tk


class StoreApp:
    def __init__(self, root):
        self.products = []
        self.root = root
        self.root.title("Store")
        self.product_name = tk.Entry(root)
        self.product_name.pack()
        self.product_price = tk.Entry(root)
        self.product_price.pack()
        self.add_button = tk.Button(root, text="Add Product", command=self.add_product)
        self.add_button.pack()
        self.show_button = tk.Button(root, text="Show Products", command=self.show_products)
        self.show_button.pack()

    def add_product(self):
        name = self.product_name.get()
        price = self.product_price.get()
        self.products.append({'name': name, 'price': price})

    def show_products(self):
        for product in self.products:
            print(f"Product: {product['name']}, Price: {product['price']}")


root = tk.Tk()
app = StoreApp(root)
root.mainloop()

from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

# MySQL Database Connection
def connect_to_database():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',  # Change this to your MySQL username
            password='',  # Change this to your MySQL password
            database='city_electronics'  # Change this to your MySQL database name
        )
        print("Connected to MySQL Database")
        return conn
    except mysql.connector.Error as e:
        print(f"Error: Could not connect to the database. Details: {e}")
        messagebox.showerror("Database Connection Error", f"Could not connect to the database. Details: {e}")
        return None

conn = connect_to_database()

# Orders list to store customer orders
orders = []

# Window setup
root = Tk()
root.geometry("700x500+300+150")
root.title("City Electronics Management System")

# Create Notebook
notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand='yes')

# Create frames for each tab
login_frame = Frame(notebook)
admin_frame = Frame(notebook)
customer_frame = Frame(notebook)

notebook.add(login_frame, text="Login")
notebook.add(admin_frame, text="Admin Dashboard")
notebook.add(customer_frame, text="Customer Dashboard")

# Fetch products from the database
def fetch_products():
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM products")
    return cursor.fetchall()


# Functions for managing products in the database
def add_product():
    product_name = entry_product_name.get()
    product_price = entry_product_price.get()
    if product_name and product_price:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO products (name, price) VALUES (%s, %s)", (product_name, product_price))
        conn.commit()
        messagebox.showinfo("Success", f"Product '{product_name}' added successfully!")
        entry_product_name.delete(0, END)
        entry_product_price.delete(0, END)
        update_customer_frame()
    else:
        messagebox.showwarning("Input Error", "Please provide both product name and price")

def modify_product():
    product_name = entry_product_name.get()
    product_price = entry_product_price.get()
    if product_name and product_price:
        cursor = conn.cursor()
        cursor.execute("UPDATE products SET price = %s WHERE name = %s", (product_price, product_name))
        conn.commit()
        messagebox.showinfo("Success", f"Product '{product_name}' modified successfully!")
        entry_product_name.delete(0, END)
        entry_product_price.delete(0, END)
        update_customer_frame()
    else:
        messagebox.showwarning("Input Error", "Please provide both product name and price")

def remove_product():
    product_name = entry_product_name.get()
    if product_name:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM products WHERE name = %s", (product_name,))
        conn.commit()
        messagebox.showinfo("Success", f"Product '{product_name}' removed successfully!")
        entry_product_name.delete(0, END)
        entry_product_price.delete(0, END)
        update_customer_frame()
    else:
        messagebox.showwarning("Input Error", "Please provide the product name")

def refresh_orders():
    order_list.delete(0, END)
    for order in orders:
        order_list.insert(END, order)

def place_order():
    total = 0
    order_summary = "Order Summary:\n"
    db_products = fetch_products()  # Fetch fresh product data from the database

    for product in db_products:
        qty = int(selected_products[product['name']].get())
        if qty > 0:
            cost = qty * product['price']
            total += cost
            order_summary += f"{product['name']}: {qty} x ${product['price']} = ${cost}\n"

    if total > 0:
        order_summary += f"\nTotal Payment: ${total}"
        orders.append(order_summary)
        messagebox.showinfo("Order Summary", order_summary)
    else:
        messagebox.showwarning("Input Error", "Please select at least one product")

# Update Customer Frame with Products from Database
def update_customer_frame():
    for widget in customer_frame.winfo_children():
        widget.destroy()

    Label(customer_frame, text="Welcome, Place your order", font=('Helvetica', 18, 'bold')).pack(pady=20)
    Label(customer_frame, text="Products:", font=('Helvetica', 12)).pack(pady=10)

    selected_products.clear()
    db_products = fetch_products()

    for product in db_products:
        frame = Frame(customer_frame)
        frame.pack(pady=5)
        Label(frame, text=f"{product['name']} - ${product['price']}", font=('Helvetica', 12)).pack(side=LEFT)
        qty_entry = Entry(frame, width=5)
        qty_entry.insert(0, '0')
        qty_entry.pack(side=LEFT, padx=10)
        selected_products[product['name']] = qty_entry

    Button(customer_frame, text="Place Order", command=place_order).pack(pady=20)


# Event handling functions
def on_entry(e):
    user.delete(0, 'end')

def on_password(e):
    name = user.get()
    if name == '':
        user.insert(0, 'Username')

def on_enter(e):
    code.delete(0, 'end')

def on_leave(e):
    password = code.get()
    if password == '':
        code.insert(0, 'Password')

# Login Function
def login():
    if conn is None:
        messagebox.showerror("Database Connection Error", "No database connection established.")
        return

    selected_role = role_var.get().strip().lower()  # Get the selected role, trimmed and lowercase
    entered_username = user.get().strip()
    entered_password = code.get().strip()

    cursor = conn.cursor()
    cursor.execute("SELECT username, password, role FROM users WHERE username = %s", (entered_username,))
    row = cursor.fetchone()

    if row:
        db_password = row[1]
        db_role = row[2].strip().lower()  # Get the role from the database, trimmed and lowercase

        # Compare the entered password and the role
        if entered_password == db_password:
            if selected_role == db_role:
                messagebox.showinfo("Login Successful", "Login Successful")
                if db_role == "admin":
                    notebook.select(admin_frame)  # Switch to admin dashboard
                elif db_role == "customer":
                    notebook.select(customer_frame)  # Switch to customer dashboard
                    update_customer_frame()  # Update customer frame after login
            else:
                messagebox.showerror("Login Failed", "Incorrect role selected")
        else:
            messagebox.showerror("Login Failed", "Invalid Username or Password")
    else:
        messagebox.showerror("Login Failed", "Invalid Username or Password")

# Login Frame Contents
heading = Label(login_frame, text='Welcome', fg='#57a1f8', bg='white', font=('Calibre', 23, 'bold'))
heading.place(x=70, y=4)

# Role selection
role_var = StringVar()
role_var.set("customer")  # Default role

Label(login_frame, text="Select Role:", bg='floral white', font=('Harrington', 11, 'bold')).place(x=30, y=40)
Radiobutton(login_frame, text="Admin", variable=role_var, value="admin", bg='floral white').place(x=120, y=40)
Radiobutton(login_frame, text="Customer", variable=role_var, value="customer", bg='floral white').place(x=200, y=40)

# User section
user = Entry(login_frame, width=25, fg='black', border=1, bg='white', font=('Harrington', 11, 'bold'))
user.place(x=30, y=80)
user.insert(0, 'Username')
user.bind('<FocusIn>', on_entry)
user.bind('<FocusOut>', on_password)

Frame(login_frame, width=295, height=2, bg='black').place(x=25, y=107)

# Password section
code = Entry(login_frame, width=25, fg='black', border=1, bg='white', font=('Harrington', 11, 'bold'))
code.place(x=30, y=150)
code.insert(0, "Password")
code.bind('<FocusIn>', on_enter)
code.bind('<FocusOut>', on_leave)

Frame(login_frame, width=295, height=2, bg='black').place(x=25, y=177)

# Buttons
Button(login_frame, width=30, pady=7, text='Login', bg='#57a1f8', fg='white', cursor='hand2', border=0, command=login).place(x=35, y=200)

# Admin Frame Contents
Label(admin_frame, text="Welcome to Admin", font=('Helvetica', 18, 'bold')).pack(pady=20)

Label(admin_frame, text="Product Name").pack()
entry_product_name = Entry(admin_frame)
entry_product_name.pack()

Label(admin_frame, text="Product Price").pack()
entry_product_price = Entry(admin_frame)
entry_product_price.pack()

Button(admin_frame, text="Add Product", command=add_product).pack(pady=5)
Button(admin_frame, text="Modify Product", command=modify_product).pack(pady=5)
Button(admin_frame, text="Remove Product", command=remove_product).pack(pady=5)

Label(admin_frame, text="Orders", font=('Helvetica', 14, 'bold')).pack(pady=10)
order_list = Listbox(admin_frame)
order_list.pack(fill=BOTH, expand=True)

Button(admin_frame, text="Refresh Orders", command=refresh_orders).pack(pady=5)

# Customer Frame Contents
Label(customer_frame, text="Welcome, Place your order", font=('Helvetica', 18, 'bold')).pack(pady=20)

Label(customer_frame, text="Products:", font=('Helvetica', 12)).pack(pady=10)

selected_products = {}

root.mainloop()

class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

class Store:
    def __init__(self):
        self.products = []

    def add_product(self, product):
        self.products.append(product)

    def show_products(self):
        for product in self.products:
            print(f"Product: {product.name}, Price: {product.price}")

store = Store()
laptop = Product('Laptop', 1200)
store.add_product(laptop)
store.show_products()

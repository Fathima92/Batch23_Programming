products = []

def add_product(name, price):
    products.append({'name': name, 'price': price})

def show_products():
    for product in products:
        print(f"Product: {product['name']}, Price: {product['price']}")

add_product('Laptop', 1200)
show_products()

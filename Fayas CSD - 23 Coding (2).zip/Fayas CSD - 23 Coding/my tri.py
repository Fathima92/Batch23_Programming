import tkinter as tk
from tkinter import messagebox
import mysql.connector

def connect_to_db():
    return mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="",
        database="costumer_db"
    )

def center_window(window, width, height):
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x_coordinate = (screen_width // 2) - (width // 2)
    y_coordinate = (screen_height // 2) - (height // 2)
    window.geometry(f"{width}x{height}+{x_coordinate}+{y_coordinate}")

def admin_login_window():
    admin_window = tk.Toplevel(root)
    admin_window.title("Admin Login")
    center_window(admin_window, 400, 300)

    admin_frame = tk.Frame(admin_window)
    admin_frame.pack(expand=True)

    tk.Label(admin_frame, text="Admin Login", font=("System", 16, "bold"), bg="cyan").grid(row=0, column=0, columnspan=2, pady=20)
    tk.Label(admin_frame, text="Username:", font=("System", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_username = tk.Entry(admin_frame)
    entry_username.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(admin_frame, text="Password:", font=("System", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky="e")
    entry_password = tk.Entry(admin_frame, show="*")
    entry_password.grid(row=2, column=1, padx=10, pady=5)

    tk.Button(admin_frame, text="Login", font=("System", 13, "bold"), command=lambda: admin_login(entry_username, entry_password)).grid(row=3, column=0, columnspan=2, pady=20)

def customer_login_window():
    customer_window = tk.Toplevel(root)
    customer_window.title("Customer Login")
    center_window(customer_window, 400, 300)

    customer_frame = tk.Frame(customer_window)
    customer_frame.pack(expand=True)

    tk.Label(customer_frame, text="Customer Login", font=("System", 16, "bold"), bg="cyan").grid(row=0, column=0, columnspan=2, pady=20)
    tk.Label(customer_frame, text="Username:", font=("System", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_username = tk.Entry(customer_frame)
    entry_username.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(customer_frame, text="Password:", font=("System", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky="e")
    entry_password = tk.Entry(customer_frame, show="*")
    entry_password.grid(row=2, column=1, padx=10, pady=5)

    tk.Button(customer_frame, text="Login", font=("System", 13, "bold"), command=lambda: customer_login(entry_username, entry_password)).grid(row=3, column=0, columnspan=2, pady=20)

def admin_login(entry_username, entry_password):
    username = entry_username.get()
    password = entry_password.get()

    if username == "" or password == "":
        messagebox.showinfo("", "Blank Not Allowed")
        return

    conn = connect_to_db()
    cursor = conn.cursor()

    try:
        query = "SELECT role FROM users WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()

        if result and result[0] == 'admin':
            messagebox.showinfo("", "Successful Login")
            open_admin_dashboard()
        else:
            messagebox.showinfo("", "Incorrect username and password")

    except mysql.connector.Error as err:
        messagebox.showerror("", f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def customer_login(entry_username, entry_password):
    username = entry_username.get()
    password = entry_password.get()

    if username == "" or password == "":
        messagebox.showinfo("", "Incomplete Blank Box")
        return

    conn = connect_to_db()
    cursor = conn.cursor()

    try:
        query = "SELECT username FROM users WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()

        if result:
            messagebox.showinfo("", "Successful Login")
            open_customer_dashboard()
        else:
            messagebox.showinfo("", "Incorrect username and password")

    except mysql.connector.Error as err:
        messagebox.showerror("", f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def open_admin_dashboard():
    admin_dashboard = tk.Toplevel(root)
    admin_dashboard.title("Admin Dashboard")
    center_window(admin_dashboard, 400, 300)

    tk.Label(admin_dashboard, text="Admin Dashboard", font=("System", 16, "bold"),bg="cyan").pack(pady=20)

    tk.Button(admin_dashboard, text="Add Admins", font=("System", 12, "bold"), command=open_add_admins_window).pack(pady=5)
    tk.Button(admin_dashboard, text="Add Products", font=("System", 12, "bold"), command=lambda: messagebox.showinfo("Add Products","Add Products functionality to be implemented")).pack(pady=5)
    tk.Button(admin_dashboard, text="Modify Product", font=("System", 12, "bold"), command=lambda: messagebox.showinfo("Modify Product", "Modify Product functionality to be implemented")).pack(pady=5)
    tk.Button(admin_dashboard, text="Remove Products", font=("System", 12, "bold"), command=lambda: messagebox.showinfo("Remove Products", "Customize Orders functionality to be implemented")).pack(pady=5)

def open_add_admins_window():
    add_admins_window = tk.Toplevel(root)
    add_admins_window.title("Add Admins")
    center_window(add_admins_window, 400, 300)

    add_admins_frame = tk.Frame(add_admins_window)
    add_admins_frame.pack(expand=True)

    tk.Label(add_admins_frame, text="ID:", font=("System", 12, "bold")).grid(row=0, column=0, padx=10, pady=5, sticky="e")
    entry_admin_id = tk.Entry(add_admins_frame)
    entry_admin_id.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(add_admins_frame, text="Name:", font=("System", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_admin_name = tk.Entry(add_admins_frame)
    entry_admin_name.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(add_admins_frame, text="Password:", font=("System", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky="e")
    entry_admin_password = tk.Entry(add_admins_frame, show="*")
    entry_admin_password.grid(row=2, column=1, padx=10, pady=5)

    tk.Button(add_admins_frame, text="Add", font=("System", 12, "bold"),bg="cyan", command=lambda: add_admin(entry_admin_id, entry_admin_name, entry_admin_password)).grid(row=3, column=0, columnspan=2, pady=20)

def add_admin(entry_id, entry_name, entry_password):
    id = entry_id.get()
    name = entry_name.get()
    password = entry_password.get()

    if id == "" or name == "" or password == "":
        messagebox.showinfo("", "All fields are required")
    else:
        conn = connect_to_db()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO admin (id, name, password) VALUES (%s, %s, %s)", (id, name, password))
            conn.commit()
            messagebox.showinfo("Success", "Admin added successfully")
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")
        finally:
            cursor.close()
            conn.close()

def open_customer_dashboard():
    customer_dashboard = tk.Toplevel(root)
    customer_dashboard.title("Customer Dashboard")
    center_window(customer_dashboard, 400, 300)

    tk.Label(customer_dashboard, text="Customer Dashboard", font=("System", 16, "bold")).pack(pady=20)

    tk.Button(customer_dashboard, text="Place Order", font=("System", 12, "bold"), command=lambda: messagebox.showinfo("Place Order", "Place Order functionality to be implemented")).pack(pady=5)
    tk.Button(customer_dashboard, text="View Orders", font=("System", 12, "bold"), command=lambda: messagebox.showinfo("View Orders", "View Orders functionality to be implemented")).pack(pady=5)
    tk.Button(customer_dashboard, text="View Products", font=("System", 12, "bold"), command=lambda: messagebox.showinfo("View Products", "View Products functionality to be implemented")).pack(pady=5)

root = tk.Tk()
root.title("City Electronics Management System")

window_width = 400
window_height = 300

center_window(root, window_width, window_height)

login_frame = tk.Frame(root)
login_frame.pack(pady=20)

login_label = tk.Label(login_frame, text="City Electronics Login", font=("System", 18, "bold"), bg="cyan")
login_label.pack(pady=10)

register_frame = tk.Frame(root)
register_frame.pack(pady=20)

admin_register_button = tk.Button(register_frame, text="Admin View", font=("System", 12, "bold"), bg="blue", command=admin_login_window)
admin_register_button.pack(pady=5)

customer_register_button = tk.Button(register_frame, text="Customer View", font=("System", 12, "bold"), bg="green", command=customer_login_window)
customer_register_button.pack(pady=10)

root.mainloop()

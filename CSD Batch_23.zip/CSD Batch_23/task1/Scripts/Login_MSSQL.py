import tkinter as tk
from tkinter import messagebox
from tkinter import font as tkfont
import pyodbc

def connect_db():
    try:
        conn = pyodbc.connect('DRIVER={SQL Server};'
                              'SERVER=DESKTOP-2DUEV8S\\SQLEXPRESS02;'
                              'DATABASE=City Electronics;'
                              'Trusted_Connection=yes;')
        return conn
    except pyodbc.Error as e:
        messagebox.showerror("Database Error", str(e))
        return None

def validate_user(username, password, role):
    conn = connect_db()
    if conn is None:
        return False

    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM Login WHERE Username = ? AND Password = ? AND Role = ?", 
                           (username, password, role))
            return cursor.fetchone() is not None
    finally:
        conn.close()

def login():
    username = entry_username.get().strip()
    password = entry_password.get().strip()

    if not username or not password:
        messagebox.showwarning("Input Error", "Please enter both username and password.")
        return

    if selected_role.get() == "admin":
        if validate_user(username, password, 'admin'):
            messagebox.showinfo("Login Success", f"Welcome Admin {username}!")
        else:
            messagebox.showerror("Login Failed", "Invalid admin username or password.")

    elif selected_role.get() == "customer":
        if validate_user(username, password, 'customer'):
            messagebox.showinfo("Login Success", f"Welcome Customer {username}!")
        else:
            messagebox.showerror("Login Failed", "Invalid customer username or password.")
    else:
        messagebox.showwarning("Role Selection", "Please select a role before logging in.")

root = tk.Tk()
root.title("City Electronics Management System")
root.geometry("500x500")
root.config(bg="#ADD8E6")  

title_font = tkfont.Font(family="Courier", size=20, weight="bold")
label_font = tkfont.Font(family="Helvetica", size=12)
button_font = tkfont.Font(family="Arial", size=12, weight="bold")

login_window = tk.Frame(root, bg="#B0E0E6")  
login_window.pack(pady=30, padx=20)

tk.Label(login_window, text="City Electronics Login", font=title_font, fg="#000080", bg="#B0E0E6").pack(pady=20)

tk.Label(login_window, text="Username:", font=label_font, fg="#000000", bg="#B0E0E6").pack(anchor="w", padx=20)
entry_username = tk.Entry(login_window, font=label_font, bg="#F0FFFF", fg="#000000", insertbackground="#000000")
entry_username.pack(fill="x", padx=20, pady=5)

tk.Label(login_window, text="Password:", font=label_font, fg="#000000", bg="#B0E0E6").pack(anchor="w", padx=20)
entry_password = tk.Entry(login_window, show="*", font=label_font, bg="#F0FFFF", fg="#000000", insertbackground="#000000")
entry_password.pack(fill="x", padx=20, pady=5)

role_frame = tk.LabelFrame(login_window, text="Login as", font=label_font, fg="#000080", bg="#B0E0E6", relief="ridge", bd=2)
role_frame.pack(fill="x", padx=20, pady=10)

selected_role = tk.StringVar(value="")

admin_radio = tk.Radiobutton(role_frame, text="Admin", variable=selected_role, value="admin", 
                             font=label_font, bg="#B0E0E6", fg="#000000", activebackground="#B0E0E6", 
                             activeforeground="#000080", selectcolor="#ADD8E6")
admin_radio.pack(anchor="w", padx=10, pady=5)

customer_radio = tk.Radiobutton(role_frame, text="Customer", variable=selected_role, value="customer", 
                                font=label_font, bg="#B0E0E6", fg="#000000", activebackground="#B0E0E6", 
                                activeforeground="#000080", selectcolor="#ADD8E6")
customer_radio.pack(anchor="w", padx=10, pady=5)

tk.Button(login_window, text="Login", bg="#4682B4", fg="#FFFFFF", font=button_font, 
          activebackground="#5F9EA0", activeforeground="#FFFFFF", 
          command=login).pack(pady=20)

root.mainloop()

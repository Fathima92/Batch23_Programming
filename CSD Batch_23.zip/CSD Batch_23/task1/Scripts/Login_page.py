import tkinter as tk
from tkinter import messagebox

# Admin credentials (hardcoded)
ADMIN_CREDENTIALS = {"admin": "admin123"}

def admin_login_page():
    login_window = tk.Tk()
    login_window.title("City Electronics Admin Login")
    login_window.geometry("500x400")
    login_window.configure(bg="lightblue")

    tk.Label(
        login_window, text="City Electronics Admin Login", font=("Arial", 16, "bold"), bg="white", fg="black"
    ).pack(pady=20)

    tk.Label(login_window, text="Username", bg="#f4e1d2").pack()
    username_entry = tk.Entry(login_window)
    username_entry.pack()

    tk.Label(login_window, text="Password", bg="#f4e1d2").pack()
    password_entry = tk.Entry(login_window, show="*")
    password_entry.pack()

    def verify_admin():
        username = username_entry.get()
        password = password_entry.get()
        if username in ADMIN_CREDENTIALS and ADMIN_CREDENTIALS[username] == password:
            messagebox.showinfo("Login Successful", "Welcome Admin!")
            # You can add a function call for the admin dashboard here.
        else:
            messagebox.showerror("Login Failed", "Invalid credentials!")

    tk.Button(
        login_window, text="Login", font=("Arial", 14), bg="#6a1b9a", fg="white",
        command=verify_admin
    ).pack(pady=40)

    login_window.mainloop()

# Run the Admin Login Page
admin_login_page()
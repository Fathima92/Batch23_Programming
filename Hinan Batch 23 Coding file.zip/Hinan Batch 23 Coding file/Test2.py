import tkinter as tk
from tkinter import messagebox
import mysql.connector

# Database Connection
def connect_to_db():
    return mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="",
        database="city electronics store"
    )

# Function to center a window
def center_window(window, width, height):
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x_coordinate = (screen_width // 2) - (width // 2)
    y_coordinate = (screen_height // 2) - (height // 2)
    window.geometry(f"{width}x{height}+{x_coordinate}+{y_coordinate}")

# Admin Login Window
def admin_login_window():
    admin_window = tk.Toplevel(root)
    admin_window.title("Admin Login")
    center_window(admin_window, 400, 300)

    admin_frame = tk.Frame(admin_window)
    admin_frame.pack(expand=True)

    tk.Label(admin_frame, text="Admin Login", font=("Arial", 16, "bold")).grid(row=0, column=0, columnspan=2, pady=20)
    tk.Label(admin_frame, text="Username:", font=("Arial", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_username = tk.Entry(admin_frame)
    entry_username.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(admin_frame, text="Password:", font=("Arial", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky="e")
    entry_password = tk.Entry(admin_frame, show="*")
    entry_password.grid(row=2, column=1, padx=10, pady=5)

    tk.Button(admin_frame, text="Login", font=("Arial", 13, "bold"), command=lambda: admin_login(entry_username, entry_password)).grid(row=3, column=0, columnspan=2, pady=20)

# Customer Login Window
def customer_login_window():
    customer_window = tk.Toplevel(root)
    customer_window.title("Customer Login")
    center_window(customer_window, 400, 300)

    customer_frame = tk.Frame(customer_window)
    customer_frame.pack(expand=True)

    tk.Label(customer_frame, text="Customer Login", font=("Arial", 16, "bold")).grid(row=0, column=0, columnspan=2, pady=20)
    tk.Label(customer_frame, text="Username:", font=("Arial", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_username = tk.Entry(customer_frame)
    entry_username.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(customer_frame, text="Password:", font=("Arial", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky="e")
    entry_password = tk.Entry(customer_frame, show="*")
    entry_password.grid(row=2, column=1, padx=10, pady=5)

    tk.Button(customer_frame, text="Login", font=("Arial", 13, "bold"), command=lambda: customer_login(entry_username, entry_password)).grid(row=3, column=0, columnspan=2, pady=20)

# Admin Login Function
def admin_login(entry_username, entry_password):
    username = entry_username.get()
    password = entry_password.get()

    if username == "" or password == "":
        messagebox.showinfo("", "Blank Not Allowed")
    else:
        try:
            conn = connect_to_db()
            cursor = conn.cursor()

            # Query to check if the admin exists
            cursor.execute("SELECT * FROM admin WHERE Name = %s AND password = %s", (username, password))
            result = cursor.fetchone()

            if result:
                messagebox.showinfo("", "Login success")
                open_admin_dashboard()
            else:
                messagebox.showinfo("", "Incorrect username or password")

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

# Customer Login Function
def customer_login(entry_username, entry_password):
    username = entry_username.get()
    password = entry_password.get()

    if username == "" or password == "":
        messagebox.showinfo("", "Blank Not Allowed")
    elif username == "" and password == "":
        messagebox.showinfo("", "Login success")
        open_customer_dashboard()
    else:
        messagebox.showinfo("", "Incorrect username and password")

# Open Admin Dashboard
def open_admin_dashboard():
    admin_dashboard = tk.Toplevel(root)
    admin_dashboard.title("Admin Dashboard")
    center_window(admin_dashboard, 400, 300)

    tk.Label(admin_dashboard, text="Admin Dashboard", font=("Arial", 16, "bold")).pack(pady=20)

    tk.Button(admin_dashboard, text="Add Admins", font=("Arial", 12, "bold"), command=open_admin_window).pack(pady=5)
    tk.Button(admin_dashboard, text="Add Products", font=("Arial", 12, "bold"), command=lambda: messagebox.showinfo("Add Products","Add Products functionality to be implemented")).pack(pady=5)
    tk.Button(admin_dashboard, text="Modify Product", font=("Arial", 12, "bold"), command=lambda: messagebox.showinfo("Modify Product", "Modify Product functionality to be implemented")).pack(pady=5)
    tk.Button(admin_dashboard, text="Customize Orders", font=("Arial", 12, "bold"), command=lambda: messagebox.showinfo("Customize Orders", "Customize Orders functionality to be implemented")).pack(pady=5)

# Open Add Admins Window
def open_admin_window():
    admin_window = tk.Toplevel(root)
    admin_window.title("Add Admins")
    center_window(admin_window, 400, 300)

    admins_frame = tk.Frame(admin_window)
    admins_frame.pack(expand=True)

    tk.Label(admins_frame, text="ID:", font=("Arial", 12, "bold")).grid(row=0, column=0, padx=10, pady=5, sticky="e")
    entry_admin_id = tk.Entry(admins_frame)
    entry_admin_id.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(admins_frame, text="Name:", font=("Arial", 12, "bold")).grid(row=1, column=0, padx=10, pady=5, sticky="e")
    entry_admin_name = tk.Entry(admins_frame)
    entry_admin_name.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(admins_frame, text="Password:", font=("Arial", 12, "bold")).grid(row=2, column=0, padx=10, pady=5, sticky="e")
    entry_admin_password = tk.Entry(admins_frame, show="*")
    entry_admin_password.grid(row=2, column=1, padx=10, pady=5)

    tk.Button(admins_frame, text="Add Admin", font=("Arial", 12, "bold"), command=lambda: add_admin(entry_admin_id.get(), entry_admin_name.get(), entry_admin_password.get())).grid(row=3, column=0, columnspan=2, pady=20)

# Add Admin Function
def add_admin(admin_id, admin_name, admin_password):
    if admin_id == "" or admin_name == "" or admin_password == "":
        messagebox.showinfo("", "All fields are required")
    else:
        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            # Insert query
            cursor.execute("INSERT INTO admin (id, Name, password) VALUES (%s, %s, %s)", (admin_id, admin_name, admin_password))
            conn.commit()
            messagebox.showinfo("", "Admin added successfully")
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error: {err}")
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

# Open Customer Dashboard
def open_customer_dashboard():
    customer_dashboard = tk.Toplevel(root)
    customer_dashboard.title("Customer Dashboard")
    center_window(customer_dashboard, 400, 300)

    tk.Label(customer_dashboard, text="Customer Dashboard", font=("Arial", 16, "bold")).pack(pady=20)

    tk.Button(customer_dashboard, text="Place Order", font=("Arial", 12, "bold"), command=lambda: messagebox.showinfo("Place Order", "Place Order functionality to be implemented")).pack(pady=5)
    tk.Button(customer_dashboard, text="View Orders", font=("Arial", 12, "bold"), command=lambda: messagebox.showinfo("View Orders", "View Orders functionality to be implemented")).pack(pady=5)
    tk.Button(customer_dashboard, text="View Products", font=("Arial", 12, "bold"), command=lambda: messagebox.showinfo("View Products", "View Products functionality to be implemented")).pack(pady=5)

# Main Window Setup
root = tk.Tk()
root.title("City Electronics Management System")

# Set the desired window dimensions
window_width = 400
window_height = 300

# Center the main window
center_window(root, window_width, window_height)

#Login Frame
login_frame = tk.Frame(root)
login_frame.pack(pady=20)

login_label = tk.Label(login_frame, text="City Electronics Login", font=("Arial", 18, "bold"))
login_label.pack(pady=10)

# Registration Buttons Frame
register_frame = tk.Frame(root)
register_frame.pack(pady=20)

admin_register_button = tk.Button(register_frame, text="Register as Admin", font=("Arial", 12, "bold"), command=admin_login_window)
admin_register_button.pack(pady=5)

customer_register_button = tk.Button(register_frame, text="Register as Customer", font=("Arial", 12, "bold"), command=customer_login_window)
customer_register_button.pack(pady=10)

root.mainloop()
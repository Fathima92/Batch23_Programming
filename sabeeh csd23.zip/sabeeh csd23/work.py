import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import mysql.connector

class CityElectronicsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("City Electronics")
        self.root.geometry("400x300")
        self.root.config(bg="#f4f4f9")  # Light gray background

        # Database connection setup
        self.conn = None
        self.cursor = None
        self.connect_to_database()

        # UI Components
        self.signin_label = ttk.Label(self.root, text="City Electronics", font=("Helvetica Neue", 30, "bold"), background="#f4f4f9")
        self.signin_label.pack(pady=20)

        self.admin_login_button = ttk.Button(self.root, text="Admin Login", command=self.admin_login, width=20)
        self.admin_login_button.pack(pady=10)

        self.customer_login_button = ttk.Button(self.root, text="Customer Login", command=self.customer_login, width=20)
        self.customer_login_button.pack(pady=10)

        self.exit_button = ttk.Button(self.root, text="Exit", command=self.quit_app, width=20)
        self.exit_button.pack(pady=20)

    def connect_to_database(self):
        """Establish a database connection"""
        try:
            self.conn = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="",
                database="city_electronics"
            )
            self.cursor = self.conn.cursor()
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", f"Error connecting to database: {e}")
            self.quit_app()

    def close_database_connection(self):
        """Close the database connection when the app is exited"""
        if self.conn and self.cursor:
            self.cursor.close()
            self.conn.close()

    def quit_app(self):
        """Close the application"""
        self.close_database_connection()
        self.root.quit()

    # Admin Login Window
    def admin_login(self):
        def verify_admin():
            username = admin_username_entry.get()
            password = admin_password_entry.get()

            if self.cursor is None:
                messagebox.showerror("Database Error", "Database connection not established.")
                return

            query = "SELECT * FROM admins WHERE username=%s AND password=%s"
            self.cursor.execute(query, (username, password))
            admin = self.cursor.fetchone()

            if admin:
                messagebox.showinfo("Login Successful", "Welcome, Admin!")
                self.admin_dashboard()
            else:
                messagebox.showerror("Login Failed", "Invalid admin credentials")

        admin_window = tk.Toplevel(self.root)
        admin_window.title("Admin Login")
        admin_window.geometry("325x275")
        admin_window.config(bg="#f4f4f9")

        ttk.Label(admin_window, text="Username", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)
        admin_username_entry = ttk.Entry(admin_window, font=("Helvetica Neue", 12))
        admin_username_entry.pack(pady=5)

        ttk.Label(admin_window, text="Password", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)
        admin_password_entry = ttk.Entry(admin_window, show="*", font=("Helvetica Neue", 12))
        admin_password_entry.pack(pady=5)

        ttk.Button(admin_window, text="Login", command=verify_admin, width=20).pack(pady=20)

    # Customer Login Window
    def customer_login(self):
        def verify_customer():
            username = customer_username_entry.get()
            password = customer_password_entry.get()

            if self.cursor is None:
                messagebox.showerror("Database Error", "Database connection not established.")
                return

            query = "SELECT * FROM customers WHERE username=%s AND password=%s"
            self.cursor.execute(query, (username, password))
            customer = self.cursor.fetchone()

            if customer:
                messagebox.showinfo("Login Successful", "Welcome, Customer!")
                self.customer_dashboard(customer[0])  # Pass customer ID for personalized options
            else:
                messagebox.showerror("Login Failed", "Invalid customer credentials")

        customer_window = tk.Toplevel(self.root)
        customer_window.title("Customer Login")
        customer_window.geometry("300x250")
        customer_window.config(bg="#f4f4f9")

        ttk.Label(customer_window, text="Username", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)
        customer_username_entry = ttk.Entry(customer_window, font=("Helvetica Neue", 12))
        customer_username_entry.pack(pady=5)

        ttk.Label(customer_window, text="Password", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)
        customer_password_entry = ttk.Entry(customer_window, show="*", font=("Helvetica Neue", 12))
        customer_password_entry.pack(pady=5)

        ttk.Button(customer_window, text="Login", command=verify_customer, width=20).pack(pady=20)

    # Admin Dashboard Window
    def admin_dashboard(self):
        admin_window = tk.Toplevel(self.root)
        admin_window.title("Admin Dashboard")
        admin_window.geometry("300x300")
        admin_window.config(bg="#f4f4f9")

        ttk.Button(admin_window, text="View Products", command=self.view_products, width=20).pack(pady=10)
        ttk.Button(admin_window, text="Modify Products", command=self.modify_products, width=20).pack(pady=10)
        ttk.Button(admin_window, text="View Orders", command=self.view_orders, width=20).pack(pady=10)
        ttk.Button(admin_window, text="Exit", command=admin_window.destroy, width=20).pack(pady=10)

    # Customer Dashboard Window
    def customer_dashboard(self, customer_id):
        self.customer_id = customer_id
        customer_window = tk.Toplevel(self.root)
        customer_window.title("Customer Dashboard")
        customer_window.geometry("400x350")
        customer_window.config(bg="#f4f4f9")

        ttk.Button(customer_window, text="View Products", command=self.view_products, width=20).pack(pady=10)
        ttk.Button(customer_window, text="Place Order", command=self.place_order_window, width=20).pack(pady=10)
        ttk.Button(customer_window, text="View Orders", command=self.view_order_history, width=20).pack(pady=10)
        ttk.Button(customer_window, text="Exit", command=customer_window.destroy, width=20).pack(pady=10)

    # View Products Window (For Both Admin and Customer)
    def view_products(self):
        products_window = tk.Toplevel(self.root)
        products_window.title("Products")
        products_window.geometry("400x300")
        products_window.config(bg="#f4f4f9")

        if self.cursor is None:
            messagebox.showerror("Database Error", "Database connection not established.")
            return

        query = "SELECT * FROM products"
        self.cursor.execute(query)
        products = self.cursor.fetchall()

        for product in products:
            ttk.Label(products_window, text=f"ID: {product[0]} | Name: {product[1]} | Price: {product[2]}", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)

        ttk.Button(products_window, text="Exit", command=products_window.destroy, width=20).pack(pady=20)

    # Place Order Window (For Customer)
    def place_order_window(self):
        def place_order():
            selected_product_id = product_id_entry.get()
            quantity = int(quantity_entry.get())

            if not selected_product_id.isdigit() or quantity <= 0:
                messagebox.showerror("Input Error", "Please enter valid product ID and quantity.")
                return

            product_id = int(selected_product_id)
            query = "SELECT * FROM products WHERE id=%s"
            self.cursor.execute(query, (product_id,))
            product = self.cursor.fetchone()

            if product:
                total_price = product[2] * quantity
                query = "INSERT INTO orders (customer_id, product_id, quantity, total_price) VALUES (%s, %s, %s, %s)"
                self.cursor.execute(query, (self.customer_id, product_id, quantity, total_price))
                self.conn.commit()
                messagebox.showinfo("Order Placed", f"Your order has been placed. Total Price: {total_price}")
            else:
                messagebox.showerror("Product Not Found", "Product ID not valid.")

        order_window = tk.Toplevel(self.root)
        order_window.title("Place Order")
        order_window.geometry("400x250")
        order_window.config(bg="#f4f4f9")

        ttk.Label(order_window, text="Product ID", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)
        product_id_entry = ttk.Entry(order_window, font=("Helvetica Neue", 12))
        product_id_entry.pack(pady=5)

        ttk.Label(order_window, text="Quantity", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)
        quantity_entry = ttk.Entry(order_window, font=("Helvetica Neue", 12))
        quantity_entry.pack(pady=5)

        ttk.Button(order_window, text="Place Order", command=place_order, width=20).pack(pady=20)

    # Admin Modify Products Window (Add/Edit/Delete Products)
    def modify_products(self):
        pass  # Add functionality to manage products (Add/Edit/Delete)

    # Admin View Orders Window
    def view_orders(self):
        pass  # Add functionality to view customer orders

    # Customer View Order History
    def view_order_history(self):
        order_history_window = tk.Toplevel(self.root)
        order_history_window.title("Order History")
        order_history_window.geometry("400x300")
        order_history_window.config(bg="#f4f4f9")

        if self.cursor is None:
            messagebox.showerror("Database Error", "Database connection not established.")
            return

        query = "SELECT * FROM orders WHERE customer_id=%s"
        self.cursor.execute(query, (self.customer_id,))
        orders = self.cursor.fetchall()

        if orders:
            for order in orders:
                ttk.Label(order_history_window, text=f"Order ID: {order[0]} | Product ID: {order[2]} | Quantity: {order[3]} | Total: {order[4]}", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=5)
        else:
            ttk.Label(order_history_window, text="No orders found.", font=("Helvetica Neue", 12), background="#f4f4f9").pack(pady=10)

        ttk.Button(order_history_window, text="Exit", command=order_history_window.destroy, width=20).pack(pady=20)

if __name__ == "__main__":
    root = tk.Tk()
    app = CityElectronicsApp(root)
    root.mainloop()
